import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { auth, api, invitesClient, ws, notifications } from '@appdeploy/client';
import {
  ArrowDownLeft,
  ArrowLeft,
  ArrowUpRight,
  Bell,
  BellRing,
  Check,
  ChevronDown,
  CircleHelp,
  Clock3,
  CreditCard,
  Download,
  FileSpreadsheet,
  FileText,
  Filter,
  Upload,
  IndianRupee,
  Languages,
  LayoutDashboard,
  LogOut,
  Menu,
  Plus,
  Pencil,
  RefreshCw,
  Search,
  ShieldCheck,
  Star,
  Trash2,
  UserMinus,
  Users,
  UserRound,
  WalletCards,
  X,
} from 'lucide-react';

import * as XLSX from 'xlsx';
import { jsPDF } from 'jspdf';
import autoTable from 'jspdf-autotable';

type User = { userId: string; name?: string; email?: string; picture?: string };
type Family = { id: string; name: string; role: 'owner' | 'member' };
type FamilyMember = { userId: string; name: string; role: 'owner' | 'member'; joinedAt?: number };
type Expense = {
  id: string;
  familyId: string;
  amount: number;
  reason: string;
  currency: 'INR';
  creatorId: string;
  creatorName: string;
  creatorPicture?: string;
  createdAt: number;
  deletedAt?: number;
};
type Income = { id: string; familyId: string; amount: number; source: string; currency: 'INR'; creatorId: string; creatorName: string; creatorPicture?: string; createdAt: number };
type Lang = 'hi' | 'en' | 'ur';
type MainSection = 'dashboard' | 'expenses' | 'income' | 'deleted' | 'reports' | 'members';
type DashboardMetric = 'familyIncome' | 'familyMonthIncome' | 'myIncome' | 'myMonthIncome' | 'mySpent' | 'myMonthSpent' | 'familySpent' | 'familyMonthSpent' | 'myBalance' | 'allExpenses';
type ImportPreviewRow = { rowNumber: number; amount: number; reason: string; error?: string };
const copy = {
  hi: {
    overview: 'घर का खर्च',
    subtitle: 'हर साझा खर्च, उसे जोड़ने वाले सदस्य के नाम के साथ।',
    add: 'खर्च जोड़ें',
    total: 'कुल खर्च',
    month: 'इस महीने',
    entries: 'कुल एंट्री',
    recent: 'हाल की गतिविधि',
    updates: 'नई एंट्री यहाँ अपने-आप दिखेंगी।',
    all: 'सभी',
    thisMonth: 'इस महीने',
    invite: 'परिवार को आमंत्रित करें',
    family: 'आपका परिवार',
    familyText: 'घर के खर्च को एक जगह मिलकर दर्ज करें।',
    share: 'परिवार का लिंक साझा करें',
    empty: 'अभी कोई खर्च नहीं है',
    emptyText: 'पहला खर्च जोड़कर शुरुआत करें।',
    create: 'परिवार बनाएँ',
    name: 'परिवार का नाम',
    amount: 'रकम (₹)',
    reason: 'किसलिए खर्च किया?',
    save: 'खर्च सेव करें',
    cancel: 'रद्द करें',
    signIn: 'साइन इन करें',
    signInText:
      'अपने परिवार के खर्च सुरक्षित रूप से देखने और जोड़ने के लिए साइन इन करें।',
    live: 'लाइव कनेक्टेड',
    connecting: 'कनेक्ट हो रहा है',
    offline: 'कनेक्शन नहीं है',
    signOut: 'साइन आउट',
    workspace: 'वर्कस्पेस',
    activity: 'खर्च',
    inviteCopied: 'आमंत्रण लिंक तैयार है',
    join: 'परिवार से जुड़ें',
    retry: 'फिर कोशिश करें',
    noFamily: 'अभी कोई परिवार नहीं',
    noFamilyText: 'परिवार बनाएँ या किसी सदस्य से आमंत्रण लिंक लें।',
    creator: 'जोड़ा',
    delete: 'हटाएँ',
    edit: 'संपादित करें',
    editExpense: 'खर्च संपादित करें',
    editGroup: 'समूह का नाम बदलें',
    deleteGroup: 'समूह हटाएँ',
    saveChanges: 'बदलाव सेव करें',
    confirmDelete: 'क्या आप यह खर्च हटाना चाहते हैं?',
    confirmDeleteGroup: 'क्या आप यह समूह और उसमें मौजूद सभी खर्च हटाना चाहते हैं? यह कार्रवाई वापस नहीं होगी।',
    welcome: 'नमस्ते',
    familyHint: 'आपका डेटा सिर्फ परिवार के सदस्यों के साथ साझा होता है।',
    error: 'कुछ गलत हुआ। कृपया फिर कोशिश करें।',
    createGroupLabel: 'नया समूह बनाएँ', switchGroupLabel: 'समूह बदलें', inviteLinkLabel: 'आमंत्रण लिंक', profileMenuLabel: 'प्रोफ़ाइल विकल्प', dateLabel: 'तारीख', expenseDetails: 'खर्च का विवरण', actionLabel: 'कार्रवाई', memberFilter: 'परिवार का सदस्य', allMembers: 'सभी सदस्य', memberBreakdown: 'सदस्य के अनुसार खर्च', dailyReport: 'एक दिन का खर्च', dailyTotal: 'इस दिन का कुल खर्च', expenseCount: 'खर्चों की संख्या', dayLabel: 'दिन', noDailyExpenses: 'इस तारीख को कोई खर्च नहीं है', enableNotifications: 'Push notifications चालू करें', disableNotifications: 'Push notifications बंद करें', notificationsEnabled: 'Notifications चालू हैं', groupFilter: 'समूह', dateFilter: 'एक तारीख चुनें', clearFilters: 'फ़िल्टर हटाएँ',
    menu: 'मेन्यू', pageTitle: 'खर्च', pageTitleAccent: 'साथ में।', sharedHousehold: 'साझा घरेलू खर्च', createSpace: 'समूह बनाएँ', realtimeSync: 'लाइव सिंक चालू', serverSaved: 'खर्च सर्वर पर सुरक्षित हैं', allRecorded: 'अब तक के सभी खर्च', currentMonth: 'इस कैलेंडर महीने के खर्च', sharedRecords: 'साझा पारिवारिक रिकॉर्ड', loadMore: 'और देखें', sharedSecure: 'साझा और सुरक्षित', familyWorkspace: 'परिवार का वर्कस्पेस', sharedInvited: 'आमंत्रित सदस्यों के साथ साझा', newEntry: 'नई एंट्री', expenseHint: 'घर के खर्च का विवरण दर्ज करें।', reasonPlaceholder: 'जैसे राशन, बिजली बिल...', familySpace: 'परिवार समूह', groupHint: 'अपने सभी जुड़े हुए खर्च समूह यहाँ देखें। समूह बदलने से पुराने खर्च नहीं हटेंगे।', createdByYou: 'आपने बनाया', joinedGroup: 'जुड़ा हुआ समूह', groupListLabel: 'आपके खर्च समूह', saving: 'सेव हो रहा है…', creating: 'बन रहा है…', joining: 'जुड़ रहे हैं…', familyMember: 'परिवार का सदस्य', signedIn: 'साइन इन है', setDefaultGroup: 'डिफ़ॉल्ट समूह बनाएँ', defaultGroup: 'डिफ़ॉल्ट', groupMembers: 'समूह के सदस्य', removeMember: 'सदस्य हटाएँ', confirmRemoveMember: 'क्या आप इस सदस्य को समूह से हटाना चाहते हैं?', ownerRole: 'मालिक', memberRole: 'सदस्य',
  },
  en: {
    overview: 'Household overview',
    subtitle: 'Every shared expense, recorded by the person who added it.',
    add: 'Add expense',
    total: 'Total expenses',
    month: 'This month',
    entries: 'Family entries',
    recent: 'Recent activity',
    updates: 'Updates show up here automatically.',
    all: 'All time',
    thisMonth: 'This month',
    invite: 'Invite family',
    family: 'Your family',
    familyText: 'Track household spending together in one place.',
    share: 'Share family invite',
    empty: 'No expenses here yet',
    emptyText: 'Add the first expense to get started.',
    create: 'Create family',
    name: 'Family name',
    amount: 'Amount (₹)',
    reason: 'What was it for?',
    save: 'Save expense',
    cancel: 'Cancel',
    signIn: 'Sign in',
    signInText: 'Sign in to securely view and add your family expenses.',
    live: 'Live connected',
    connecting: 'Connecting',
    offline: 'Disconnected',
    signOut: 'Sign out',
    workspace: 'Workspace',
    activity: 'Expenses',
    inviteCopied: 'Invite link is ready',
    join: 'Join family',
    retry: 'Try again',
    noFamily: 'No family yet',
    noFamilyText: 'Create a family or ask a member for an invite link.',
    creator: 'Added by',
    delete: 'Delete',
    edit: 'Edit',
    editExpense: 'Edit expense',
    editGroup: 'Rename group',
    deleteGroup: 'Delete group',
    saveChanges: 'Save changes',
    confirmDelete: 'Delete this expense?',
    confirmDeleteGroup: 'Delete this group and all of its expenses? This cannot be undone.',
    welcome: 'Welcome',
    familyHint: 'Your data is shared only with family members.',
    error: 'Something went wrong. Please try again.',
    createGroupLabel: 'Create group', switchGroupLabel: 'Switch group', inviteLinkLabel: 'Invite link', profileMenuLabel: 'Profile options', dateLabel: 'Date', expenseDetails: 'Expense details', actionLabel: 'Action', memberFilter: 'Family member', allMembers: 'All members', memberBreakdown: 'Spending by member', dailyReport: 'Daily expense report', dailyTotal: 'Total spent on this day', expenseCount: 'Expense count', dayLabel: 'Day', noDailyExpenses: 'No expenses on this date', enableNotifications: 'Enable push notifications', disableNotifications: 'Turn off push notifications', notificationsEnabled: 'Notifications are enabled', groupFilter: 'Group', dateFilter: 'Filter by date', clearFilters: 'Clear filters',
    menu: 'Menu', pageTitle: 'Expenses', pageTitleAccent: 'together.', sharedHousehold: 'Shared household', createSpace: 'Create a space', realtimeSync: 'Realtime sync on', serverSaved: 'Expense data is saved on server', allRecorded: 'All recorded expenses', currentMonth: 'Current calendar month', sharedRecords: 'Shared family records', loadMore: 'Load more', sharedSecure: 'Shared & secure', familyWorkspace: 'Family workspace', sharedInvited: 'Shared with invited members', newEntry: 'New entry', expenseHint: 'Enter the household expense details.', reasonPlaceholder: 'e.g. groceries, electricity bill...', familySpace: 'Family space', groupHint: 'View all your linked expense groups here. Switching groups will not remove saved expenses.', createdByYou: 'Created by you', joinedGroup: 'Joined group', groupListLabel: 'Your expense groups', saving: 'Saving…', creating: 'Creating…', joining: 'Joining…', familyMember: 'Family member', signedIn: 'Signed in', setDefaultGroup: 'Set as default', defaultGroup: 'Default', groupMembers: 'Group members', removeMember: 'Remove member', confirmRemoveMember: 'Remove this member from the group?', ownerRole: 'Owner', memberRole: 'Member',
  },
  ur: {
    overview: 'گھر کے اخراجات',
    subtitle: 'ہر مشترکہ خرچ، اسے شامل کرنے والے فرد کے ساتھ۔',
    add: 'خرچ شامل کریں',
    total: 'کل اخراجات',
    month: 'اس ماہ',
    entries: 'خاندانی اندراجات',
    recent: 'حالیہ سرگرمی',
    updates: 'نئی معلومات خود یہاں نظر آئیں گی۔',
    all: 'تمام وقت',
    thisMonth: 'اس ماہ',
    invite: 'خاندان کو مدعو کریں',
    family: 'آپ کا خاندان',
    familyText: 'گھر کے اخراجات ایک جگہ مل کر درج کریں۔',
    share: 'دعوتی لنک شیئر کریں',
    empty: 'ابھی کوئی خرچ نہیں',
    emptyText: 'شروع کرنے کے لیے پہلا خرچ شامل کریں۔',
    create: 'خاندان بنائیں',
    name: 'خاندان کا نام',
    amount: 'رقم (₹)',
    reason: 'کس لیے خرچ کیا؟',
    save: 'خرچ محفوظ کریں',
    cancel: 'منسوخ',
    signIn: 'سائن اِن کریں',
    signInText: 'خاندان کے اخراجات دیکھنے اور شامل کرنے کے لیے سائن اِن کریں۔',
    live: 'لائیو منسلک',
    connecting: 'منسلک ہو رہا ہے',
    offline: 'منقطع',
    signOut: 'سائن آؤٹ',
    workspace: 'ورک اسپیس',
    activity: 'اخراجات',
    inviteCopied: 'دعوتی لنک تیار ہے',
    join: 'خاندان میں شامل ہوں',
    retry: 'دوبارہ کوشش',
    noFamily: 'ابھی کوئی خاندان نہیں',
    noFamilyText: 'خاندان بنائیں یا دعوتی لنک حاصل کریں۔',
    creator: 'شامل کیا',
    delete: 'حذف کریں',
    edit: 'ترمیم کریں',
    editExpense: 'خرچ میں ترمیم',
    editGroup: 'گروپ کا نام تبدیل کریں',
    deleteGroup: 'گروپ حذف کریں',
    saveChanges: 'تبدیلیاں محفوظ کریں',
    confirmDelete: 'کیا آپ یہ خرچ حذف کرنا چاہتے ہیں؟',
    confirmDeleteGroup: 'کیا آپ یہ گروپ اور اس کے تمام اخراجات حذف کرنا چاہتے ہیں؟ یہ واپس نہیں ہو سکتا۔', 
    welcome: 'خوش آمدید',
    familyHint: 'آپ کا ڈیٹا صرف خاندان کے اراکین کے ساتھ شیئر ہوتا ہے۔',
    error: 'کچھ غلط ہوا۔ دوبارہ کوشش کریں۔',
    createGroupLabel: 'نیا گروپ بنائیں', switchGroupLabel: 'گروپ تبدیل کریں', inviteLinkLabel: 'دعوتی لنک', profileMenuLabel: 'پروفائل کے اختیارات', dateLabel: 'تاریخ', expenseDetails: 'اخراجات کی تفصیل', actionLabel: 'عمل', memberFilter: 'خاندانی رکن', allMembers: 'تمام اراکین', memberBreakdown: 'رکن کے مطابق اخراجات', dailyReport: 'ایک دن کی رپورٹ', dailyTotal: 'اس دن کا کل خرچ', expenseCount: 'اخراجات کی تعداد', dayLabel: 'دن', noDailyExpenses: 'اس تاریخ کو کوئی خرچ نہیں', enableNotifications: 'پش نوٹیفکیشن آن کریں', disableNotifications: 'پش نوٹیفکیشن بند کریں', notificationsEnabled: 'نوٹیفکیشن آن ہیں', groupFilter: 'گروپ', dateFilter: 'تاریخ کے مطابق', clearFilters: 'فلٹر صاف کریں',
    menu: 'مینو', pageTitle: 'اخراجات', pageTitleAccent: 'مل کر۔', sharedHousehold: 'گھر کے مشترکہ اخراجات', createSpace: 'جگہ بنائیں', realtimeSync: 'لائیو سنک فعال', serverSaved: 'اخراجات سرور پر محفوظ ہیں', allRecorded: 'تمام درج شدہ اخراجات', currentMonth: 'اس کیلنڈر ماہ کے اخراجات', sharedRecords: 'خاندانی مشترکہ ریکارڈ', loadMore: 'مزید دیکھیں', sharedSecure: 'مشترکہ اور محفوظ', familyWorkspace: 'خاندانی ورک اسپیس', sharedInvited: 'مدعو اراکین کے ساتھ مشترکہ', newEntry: 'نیا اندراج', expenseHint: 'گھر کے خرچ کی تفصیل درج کریں۔', reasonPlaceholder: 'مثلاً راشن، بجلی کا بل...', familySpace: 'خاندانی جگہ', groupHint: 'اپنے تمام منسلک اخراجاتی گروپ یہاں دیکھیں۔ گروپ بدلنے سے محفوظ اخراجات حذف نہیں ہوں گے۔', createdByYou: 'آپ نے بنایا', joinedGroup: 'شامل شدہ گروپ', groupListLabel: 'آپ کے اخراجاتی گروپ', saving: 'محفوظ ہو رہا ہے…', creating: 'بن رہا ہے…', joining: 'شامل ہو رہے ہیں…', familyMember: 'خاندان کا رکن', signedIn: 'سائن اِن ہے', setDefaultGroup: 'ڈیفالٹ گروپ بنائیں', defaultGroup: 'ڈیفالٹ', groupMembers: 'گروپ کے اراکین', removeMember: 'رکن کو ہٹائیں', confirmRemoveMember: 'کیا اس رکن کو گروپ سے ہٹانا ہے؟', ownerRole: 'مالک', memberRole: 'رکن',
  },
};
type UiTranslation = { en: string; hi: string; ur: string };
const uiTranslations: UiTranslation[] = [
    { en: "Dashboard", hi: "डैशबोर्ड", ur: "ڈیش بورڈ" },
    { en: "FAMILY FINANCES", hi: "पारिवारिक वित्त", ur: "خاندانی مالیات" },
    { en: "WORKSPACE", hi: "वर्कस्पेस", ur: "ورک اسپیس" },
    { en: "REPORTS", hi: "रिपोर्ट्स", ur: "رپورٹس" },
    { en: "MANAGE", hi: "प्रबंधन", ur: "انتظام" },
    { en: "Expenses", hi: "खर्च", ur: "اخراجات" },
    { en: "Income", hi: "आय", ur: "آمدنی" },
    { en: "Deleted Expenses", hi: "हटाए गए खर्च", ur: "حذف شدہ اخراجات" },
    { en: "Spending Reports", hi: "खर्च रिपोर्ट", ur: "اخراجات کی رپورٹس" },
    { en: "Member-wise Spending", hi: "सदस्य-वार खर्च", ur: "رکن کے مطابق اخراجات" },
    { en: "Groups & Members", hi: "समूह और सदस्य", ur: "گروپس اور اراکین" },
    { en: "Settings & Notifications", hi: "सेटिंग्स और सूचनाएँ", ur: "ترتیبات اور اطلاعات" },
    { en: "Invite family", hi: "परिवार को आमंत्रित करें", ur: "خاندان کو مدعو کریں" },
    { en: "MEMBER REPORT", hi: "सदस्य रिपोर्ट", ur: "اراکین کی رپورٹ" },
    { en: "Only expense totals and entry counts for each group member.", hi: "हर समूह सदस्य के खर्च का कुल और प्रविष्टियों की संख्या।", ur: "ہر گروپ رکن کے خرچ کی کل رقم اور اندراجات کی تعداد۔" },
    { en: "Total spending", hi: "कुल खर्च", ur: "کل خرچ" },
    { en: "No member spending records yet.", hi: "अभी सदस्य-वार खर्च का कोई रिकॉर्ड नहीं है।", ur: "ابھی اراکین کے اخراجات کا کوئی ریکارڈ نہیں۔" },
    { en: "Restore an expense to return it to the main list, or permanently delete it.", hi: "खर्च को मुख्य सूची में वापस लाने के लिए बहाल करें, या उसे हमेशा के लिए हटाएँ।", ur: "خرچ کو مرکزی فہرست میں واپس لانے کے لیے بحال کریں، یا اسے مستقل حذف کریں।" },
    { en: "Back to expenses", hi: "खर्चों पर वापस जाएँ", ur: "اخراجات پر واپس جائیں" },
    { en: "No deleted expenses", hi: "कोई हटाया गया खर्च नहीं", ur: "کوئی حذف شدہ خرچ نہیں" },
    { en: "Expenses you delete will appear here so you can restore them later.", hi: "आपके हटाए गए खर्च यहाँ दिखेंगे, ताकि आप उन्हें बाद में बहाल कर सकें।", ur: "آپ کے حذف کیے گئے اخراجات یہاں دکھائی دیں گے تاکہ آپ انہیں بعد میں بحال کر سکیں۔" },
    { en: "Restore", hi: "बहाल करें", ur: "بحال کریں" },
    { en: "Permanently delete", hi: "हमेशा के लिए हटाएँ", ur: "مستقل طور پر حذف کریں" },
    { en: "No income entries for this period.", hi: "इस अवधि में आय की कोई प्रविष्टि नहीं है۔", ur: "اس مدت میں آمدنی کا کوئی اندراج نہیں۔" },
    { en: "No expense entries for this period.", hi: "इस अवधि में खर्च की कोई प्रविष्टि नहीं है۔", ur: "اس مدت میں اخراجات کا کوئی اندراج نہیں۔" },
    { en: "Your income", hi: "आपकी आय", ur: "آپ کی آمدنی" },
    { en: "Your spending", hi: "आपका खर्च", ur: "آپ کا خرچ" },
    { en: "EXPENSE RECORD", hi: "खर्च रिकॉर्ड", ur: "اخراجات کا ریکارڈ" },
    { en: "PERMANENT ACTION", hi: "स्थायी कार्रवाई", ur: "مستقل کارروائی" },
    { en: "Permanently delete this expense?", hi: "क्या इस खर्च को हमेशा के लिए हटाना है?", ur: "کیا یہ خرچ مستقل طور پر حذف کرنا ہے؟" },
    { en: "This cannot be undone. The expense will be removed from Deleted Expenses forever.", hi: "यह कार्रवाई वापस नहीं हो सकती। खर्च हटाए गए खर्चों की सूची से हमेशा के लिए हट जाएगा।", ur: "یہ عمل واپس نہیں ہو سکتا۔ خرچ حذف شدہ اخراجات کی فہرست سے ہمیشہ کے لیے ہٹا دیا جائے گا۔" },
    { en: "Row", hi: "पंक्ति", ur: "قطار" },
    { en: "FAMILY INVITATION", hi: "परिवार का निमंत्रण", ur: "خاندان کی دعوت" },
    { en: "Filters", hi: "फ़िल्टर", ur: "فلٹرز" },
    { en: "Filter & search", hi: "फ़िल्टर और खोज", ur: "فلٹر اور تلاش" },
    { en: "active", hi: "सक्रिय", ur: "فعال" },
    { en: "Import data", hi: "डेटा इम्पोर्ट करें", ur: "ڈیٹا درآمد کریں" },
    { en: "Filter expenses", hi: "खर्च फ़िल्टर करें", ur: "اخراجات فلٹر کریں" },
    { en: "EXPENSE CONTROLS", hi: "खर्च नियंत्रण", ur: "اخراجات کے کنٹرول" },
    { en: "Choose any combination. The expense list updates to match your filters.", hi: "कोई भी फ़िल्टर चुनें। खर्चों की सूची उसी के अनुसार बदलेगी।", ur: "کوئی بھی فلٹر منتخب کریں۔ اخراجات کی فہرست اسی کے مطابق بدل جائے گی।" },
    { en: "Tap a member profile to see every expense they added.", hi: "किसी सदस्य की प्रोफ़ाइल पर टैप करके उसके सभी खर्च देखें।", ur: "کسی رکن کی پروفائل پر ٹیپ کرکے اس کے تمام اخراجات دیکھیں۔" },
    { en: "expenses", hi: "खर्च", ur: "اخراجات" },
    { en: "No member expenses have been added yet.", hi: "अभी किसी सदस्य ने खर्च नहीं जोड़ा है।", ur: "ابھی کسی رکن نے خرچ شامل نہیں کیا۔" },
    { en: "Time period", hi: "समय अवधि", ur: "مدت" },
    { en: "e.g. groceries, bills, member", hi: "जैसे राशन, बिल, सदस्य", ur: "مثلاً راشن، بل، رکن" },
    { en: "Clear all", hi: "सभी साफ़ करें", ur: "سب صاف کریں" },
    { en: "Apply filters", hi: "फ़िल्टर लागू करें", ur: "فلٹر لاگو کریں" },
    { en: "Back to Dashboard", hi: "डैशबोर्ड पर वापस", ur: "ڈیش بورڈ پر واپس" },
    { en: "Filters applied", hi: "फ़िल्टर लागू हैं", ur: "فلٹر لاگو ہیں" },
    { en: "FILTER RESULTS", hi: "फ़िल्टर परिणाम", ur: "فلٹر کے نتائج" },
    { en: "Filtered expenses", hi: "फ़िल्टर किए गए खर्च", ur: "فلٹر کیے گئے اخراجات" },
    { en: "Only expenses matching your selected filters are shown.", hi: "यहाँ केवल चुने गए फ़िल्टर से मेल खाने वाले खर्च दिख रहे हैं।", ur: "یہاں صرف منتخب فلٹرز سے مطابقت رکھنے والے اخراجات دکھائے جا رہے ہیں।" },
    { en: "Matching expenses", hi: "मेल खाते खर्च", ur: "مطابق اخراجات" },
    { en: "Matching total", hi: "कुल मिलान राशि", ur: "مطابق کل رقم" },
    { en: "Selected member", hi: "चुना हुआ सदस्य", ur: "منتخب رکن" },
    { en: "Date", hi: "तारीख", ur: "تاریخ" },
    { en: "This month", hi: "इस महीने", ur: "اس ماہ" },
    { en: "Search", hi: "खोजें", ur: "تلاش کریں" },
    { en: "All expenses", hi: "सभी खर्च", ur: "تمام اخراجات" },
    { en: "No matching expenses", hi: "कोई मेल खाता खर्च नहीं मिला", ur: "کوئی مطابق خرچ نہیں ملا" },
    { en: "Edit your filters or clear them to see more expenses.", hi: "और खर्च देखने के लिए फ़िल्टर बदलें या साफ़ करें।", ur: "مزید اخراجات دیکھنے کے لیے فلٹر تبدیل کریں یا صاف کریں۔" },
    { en: "Edit filters", hi: "फ़िल्टर बदलें", ur: "فلٹر تبدیل کریں" },
    { en: "SPREADSHEET IMPORT", hi: "स्प्रेडशीट इम्पोर्ट", ur: "اسپریڈشیٹ درآمد" },
    { en: "Import expense data", hi: "खर्च डेटा इम्पोर्ट करें", ur: "اخراجات کا ڈیٹا درآمد کریں" },
    { en: "Choose an Excel or CSV file with Amount and Expense/Reason columns. Review rows before importing.", hi: "Amount और Expense/Reason कॉलम वाली Excel या CSV फ़ाइल चुनें। इम्पोर्ट से पहले पंक्तियाँ जाँचें।", ur: "Amount اور Expense/Reason کالم والی Excel یا CSV فائل منتخب کریں۔ درآمد سے پہلے قطاریں دیکھیں۔" },
    { en: "Choose an Excel/CSV file", hi: "Excel/CSV फ़ाइल चुनें", ur: "Excel/CSV فائل منتخب کریں" },
    { en: "valid rows", hi: "सही पंक्तियाँ", ur: "درست قطاریں" },
    { en: "rows need review", hi: "पंक्तियों की जाँच ज़रूरी है", ur: "قطاروں کی جانچ ضروری ہے" },
    { en: "Expense", hi: "खर्च", ur: "اخراجات" },
    { en: "Status", hi: "स्थिति", ur: "حیثیت" },
    { en: "Ready", hi: "तैयार", ur: "تیار" },
    { en: "First 8 rows are previewed. Source file dates are not applied; imported entries use the import time.", hi: "पहली 8 पंक्तियों का पूर्वावलोकन है। फ़ाइल की तारीख लागू नहीं होगी; इम्पोर्ट का समय इस्तेमाल होगा।", ur: "پہلی 8 قطاروں کا پیش منظر ہے۔ فائل کی تاریخ استعمال نہیں ہوگی؛ درآمد کا وقت استعمال ہوگا۔" },
    { en: "Importing…", hi: "इम्पोर्ट हो रहा है…", ur: "درآمد ہو رہا ہے…" },
    { en: "Import expenses", hi: "खर्च इम्पोर्ट करें", ur: "اخراجات درآمد کریں" },
    { en: "CONFIRM ACTION", hi: "पुष्टि आवश्यक", ur: "کارروائی کی تصدیق" },
    { en: "Delete this expense?", hi: "क्या यह खर्च हटाना है?", ur: "کیا یہ خرچ حذف کرنا ہے؟" },
    { en: "Delete this group?", hi: "क्या यह समूह हटाना है?", ur: "کیا یہ گروپ حذف کرنا ہے؟" },
    { en: "This expense entry will be permanently removed.", hi: "यह खर्च हमेशा के लिए हट जाएगा।", ur: "یہ خرچ مستقل طور پر حذف ہو جائے گا۔" },
    { en: "This group and all of its expenses will be permanently removed. This cannot be undone.", hi: "यह समूह और उसके सभी खर्च हमेशा के लिए हट जाएँगे। यह कार्रवाई वापस नहीं हो सकती।", ur: "یہ گروپ اور اس کے تمام اخراجات مستقل طور پر حذف ہو جائیں گے۔ یہ عمل واپس نہیں ہو سکتا۔" },
    { en: "Deleting…", hi: "हटाया जा रहा है…", ur: "حذف ہو رہا ہے…" },
    { en: "Yes, delete", hi: "हाँ, हटाएँ", ur: "ہاں، حذف کریں" },
    { en: "Remove family member?", hi: "परिवार के सदस्य को हटाएँ?", ur: "خاندان کے رکن کو ہٹائیں؟" },
    { en: "This member will lose access to this group and its shared expenses.", hi: "इस सदस्य की इस समूह और साझा खर्चों तक पहुँच समाप्त हो जाएगी।", ur: "اس رکن کی اس گروپ اور مشترکہ اخراجات تک رسائی ختم ہو جائے گی۔" },
    { en: "Removing…", hi: "हटाया जा रहा है…", ur: "ہٹایا جا رہا ہے…" },
    { en: "Yes, remove", hi: "हाँ, हटाएँ", ur: "ہاں، ہٹائیں" },
    { en: "Go back", hi: "वापस जाएँ", ur: "واپس جائیں" },
    { en: "Back", hi: "वापस", ur: "واپس" },
    { en: "Close", hi: "बंद करें", ur: "بند کریں" },
    { en: "Close details", hi: "विवरण बंद करें", ur: "تفصیلات بند کریں" },
    { en: "View details", hi: "विवरण देखें", ur: "تفصیلات دیکھیں" },
    { en: "Added by", hi: "जोड़ा गया", ur: "شامل کیا" },
    { en: "FINANCIAL BREAKDOWN", hi: "वित्तीय विवरण", ur: "مالی تفصیل" },
    { en: "EXPENSE HISTORY", hi: "खर्च इतिहास", ur: "اخراجات کی تاریخ" },
    { en: "Current calendar month", hi: "चालू कैलेंडर महीना", ur: "موجودہ کیلنڈر ماہ" },
    { en: "All recorded time", hi: "अब तक का रिकॉर्ड", ur: "اب تک کا ریکارڈ" },
    { en: "Selected group", hi: "चुना हुआ समूह", ur: "منتخب گروپ" },
    { en: "All family income", hi: "पूरे परिवार की कुल आय", ur: "پورے خاندان کی کل آمدنی" },
    { en: "All family this month income", hi: "इस महीने पूरे परिवार की आय", ur: "اس ماہ پورے خاندان کی آمدنی" },
    { en: "Your total income", hi: "आपकी कुल आय", ur: "آپ کی کل آمدنی" },
    { en: "Your this month income", hi: "इस महीने आपकी आय", ur: "اس ماہ آپ کی آمدنی" },
    { en: "Your total spent", hi: "आपका कुल खर्च", ur: "آپ کا کل خرچ" },
    { en: "Your this month spent", hi: "इस महीने आपका खर्च", ur: "اس ماہ آپ کا خرچ" },
    { en: "All family total spent", hi: "पूरे परिवार का कुल खर्च", ur: "پورے خاندان کا کل خرچ" },
    { en: "All family this month spent", hi: "इस महीने पूरे परिवार का खर्च", ur: "اس ماہ پورے خاندان کا خرچ" },
    { en: "Your remaining balance", hi: "आपका बाकी बैलेंस", ur: "آپ کا باقی بیلنس" },
    { en: "Income amount", hi: "आय की रकम", ur: "آمدنی کی رقم" },
    { en: "Enter the amount you received.", hi: "प्राप्त हुई रकम दर्ज करें।", ur: "موصول ہونے والی رقم درج کریں۔" },
    { en: "Income source", hi: "आय का स्रोत", ur: "آمدنی کا ذریعہ" },
    { en: "Save income", hi: "आय सेव करें", ur: "آمدنی محفوظ کریں" },
    { en: "shared income entries", hi: "साझा आय प्रविष्टियाँ", ur: "مشترکہ آمدنی کے اندراجات" },
    { en: "of your income entries", hi: "आपकी आय प्रविष्टियों में से", ur: "آپ کے آمدنی اندراجات میں سے" },
    { en: "expenses added by you", hi: "आपके जोड़े गए खर्च", ur: "آپ کے شامل کردہ اخراجات" },
    { en: "No income recorded yet", hi: "अभी आय दर्ज नहीं है", ur: "ابھی آمدنی درج نہیں" },
    { en: "Add income", hi: "आय जोड़ें", ur: "آمدنی شامل کریں" },
    { en: "Track group income", hi: "समूह की आय ट्रैक करें", ur: "گروپ کی آمدنی کا ریکارڈ رکھیں" },
    { en: "View income, spending and balance for every group member.", hi: "हर समूह सदस्य की आय, खर्च और बैलेंस देखें।", ur: "ہر گروپ رکن کی آمدنی، خرچ اور بیلنس دیکھیں۔" },
    { en: "Income records", hi: "आय रिकॉर्ड", ur: "آمدنی کا ریکارڈ" },
    { en: "Save changes", hi: "बदलाव सेव करें", ur: "تبدیلیاں محفوظ کریں" },
    { en: "Edit income", hi: "आय संपादित करें", ur: "آمدنی میں ترمیم کریں" },
    { en: "This entry will be visible to members of the selected group.", hi: "यह एंट्री चुने गए समूह के सदस्यों को दिखेगी।", ur: "یہ اندراج منتخب گروپ کے اراکین کو دکھائی دے گا۔" },
    { en: "e.g. Home, Trip, Personal", hi: "जैसे घर, यात्रा, व्यक्तिगत", ur: "مثلاً گھر، سفر، ذاتی" },
    { en: "No expenses on this date", hi: "इस तारीख को कोई खर्च नहीं है", ur: "اس تاریخ کو کوئی خرچ نہیں" },
    { en: "Add expense", hi: "खर्च जोड़ें", ur: "خرچ شامل کریں" },
    { en: "Expense details", hi: "खर्च का विवरण", ur: "اخراجات کی تفصیل" },
    { en: "Min", hi: "न्यूनतम", ur: "کم از کم" },
    { en: "Max", hi: "अधिकतम", ur: "زیادہ سے زیادہ" },
    { en: "Language", hi: "भाषा", ur: "زبان" },
    { en: "Open expense details", hi: "खर्च का विवरण खोलें", ur: "اخراجات کی تفصیل کھولیں" },
    { en: "Tap to view full details", hi: "पूरा विवरण देखने के लिए टैप करें", ur: "مکمل تفصیل دیکھنے کے لیے ٹیپ کریں" },
    { en: "Shared group records", hi: "समूह के साझा रिकॉर्ड", ur: "گروپ کے مشترکہ ریکارڈ" },
    { en: "Choose existing group", hi: "मौजूदा समूह चुनें", ur: "موجودہ گروپ منتخب کریں" },
    { en: "Profile options", hi: "प्रोफ़ाइल विकल्प", ur: "پروفائل کے اختیارات" },
    { en: "Dismiss notification", hi: "सूचना हटाएँ", ur: "اطلاع بند کریں" },
    { en: "Close export dialog", hi: "एक्सपोर्ट संवाद बंद करें", ur: "برآمد مکالمہ بند کریں" },
    { en: "This action cannot be undone.", hi: "यह कार्रवाई वापस नहीं हो सकती।", ur: "یہ عمل واپس نہیں ہو سکتا۔" },
    { en: "All members", hi: "सभी सदस्य", ur: "تمام اراکین" },
    { en: "Member", hi: "सदस्य", ur: "رکن" },
    { en: "Amount", hi: "रकम", ur: "رقم" },
    { en: "Action", hi: "कार्रवाई", ur: "عمل" },
    { en: "Loading…", hi: "लोड हो रहा है…", ur: "لوڈ ہو رہا ہے…" },
    { en: "No family yet", hi: "अभी कोई परिवार नहीं", ur: "ابھی کوئی خاندان نہیں" },
    { en: "Please try again.", hi: "कृपया फिर कोशिश करें।", ur: "براہ کرم دوبارہ کوشش کریں।" },
    { en: "Household overview", hi: "घर का वित्तीय विवरण", ur: "گھر کے مالیات کا جائزہ" },
    { en: "Daily expense report", hi: "दैनिक खर्च रिपोर्ट", ur: "روزانہ اخراجات کی رپورٹ" },
    { en: "Total spent on this day", hi: "इस दिन का कुल खर्च", ur: "اس دن کا کل خرچ" },
    { en: "Expense count", hi: "खर्चों की संख्या", ur: "اخراجات کی تعداد" },
    { en: "Live connected", hi: "लाइव जुड़ा हुआ", ur: "لائیو منسلک" },
    { en: "Connecting", hi: "कनेक्ट हो रहा है", ur: "منسلک ہو رہا ہے" },
    { en: "Disconnected", hi: "कनेक्शन टूट गया", ur: "منقطع" },
    { en: "Recent activity", hi: "हाल की गतिविधि", ur: "حالیہ سرگرمی" },
    { en: "Updates show up here automatically.", hi: "नई एंट्री यहाँ अपने-आप दिखेंगी।", ur: "نئی انٹری یہاں خود بخود دکھائی دے گی।" },
    { en: "No expenses here yet", hi: "अभी कोई खर्च नहीं है", ur: "ابھی کوئی خرچ نہیں" },
    { en: "Family entries", hi: "परिवार की एंट्री", ur: "خاندان کے اندراجات" },
    { en: "No results found", hi: "कोई परिणाम नहीं मिला", ur: "کوئی نتیجہ نہیں ملا" },
    { en: "Add your first income entry. Other group members can see it too.", hi: "अपनी पहली आय एंट्री जोड़ें। समूह के दूसरे सदस्य भी इसे देख सकेंगे।", ur: "اپنی پہلی آمدنی شامل کریں۔ گروپ کے دوسرے اراکین بھی اسے دیکھ سکیں گے۔" },
    { en: "Invalid amount", hi: "रकम सही नहीं है", ur: "رقم درست نہیں" },
    { en: "Missing expense description", hi: "खर्च का विवरण नहीं है", ur: "اخراجات کی تفصیل موجود نہیں" },
    { en: "No worksheet found.", hi: "शीट नहीं मिली।", ur: "ورک شیٹ نہیں ملی۔" },
    { en: "The file is empty.", hi: "फ़ाइल खाली है۔", ur: "فائل خالی ہے۔" },
    { en: "Only the first 2,000 rows are previewed.", hi: "सिर्फ पहली 2,000 पंक्तियाँ दिखाई जा रही हैं।", ur: "صرف پہلی 2,000 قطاروں کا پیش منظر دکھایا گیا ہے۔" },
    { en: "There are no valid rows to import.", hi: "इम्पोर्ट के लिए सही पंक्तियाँ नहीं हैं।", ur: "درآمد کے لیے کوئی درست قطار نہیں۔" },

    { en: "Export", hi: "एक्सपोर्ट", ur: "برآمد" },
    { en: "Import", hi: "इम्पोर्ट", ur: "درآمد" },
    { en: "e.g. groceries, name, group", hi: "जैसे राशन, नाम, समूह", ur: "مثلاً راشن، نام، گروپ" },
    { en: "Income entries shared by members of this group.", hi: "इस समूह के सदस्यों की आय प्रविष्टियाँ यहाँ साझा होती हैं।", ur: "اس گروپ کے اراکین کی آمدنی کے اندراجات یہاں مشترک ہوتے ہیں۔" },
    { en: "income entries", hi: "आय प्रविष्टियाँ", ur: "آمدنی کے اندراجات" },
    { en: "Spending", hi: "खर्च", ur: "خرچ" },
    { en: "Balance", hi: "बैलेंस", ur: "بیلنس" },
    { en: "Open expense details: ", hi: "खर्च का विवरण खोलें: ", ur: "اخراجات کی تفصیل کھولیں: " },
    { en: "Time", hi: "समय", ur: "وقت" },
    { en: "Group", hi: "समूह", ur: "گروپ" },
    { en: "Delete this income?", hi: "क्या यह आय हटानी है?", ur: "کیا یہ آمدنی حذف کرنی ہے؟" },
    { en: "This income record will be removed from the shared group list.", hi: "यह आय रिकॉर्ड समूह की साझा सूची से हटा दिया जाएगा।", ur: "آمدنی کا یہ ریکارڈ گروپ کی مشترکہ فہرست سے ہٹا دیا جائے گا۔" },
    { en: "INCOME TRACKER", hi: "आय ट्रैकर", ur: "آمدنی کا ریکارڈ" },
    { en: "Give every earning a place in your family finances.", hi: "परिवार के वित्तीय रिकॉर्ड में हर कमाई दर्ज करें।", ur: "خاندانی مالی ریکارڈ میں ہر آمدنی درج کریں۔" },
    { en: "Shared with members of the selected group.", hi: "चुने गए समूह के सदस्यों के साथ साझा होगा।", ur: "منتخب گروپ کے اراکین کے ساتھ مشترک ہوگا۔" },
    { en: "e.g. Salary, business, freelance", hi: "जैसे वेतन, व्यापार, फ्रीलांस", ur: "مثلاً تنخواہ، کاروبار، فری لانس" },
    { en: "Choose an existing group to switch to. Use Create group in the profile menu to make a new one.", hi: "बदलने के लिए मौजूदा समूह चुनें। नया समूह बनाने के लिए प्रोफ़ाइल मेन्यू का अलग विकल्प इस्तेमाल करें।", ur: "تبدیل کرنے کے لیے موجودہ گروپ منتخب کریں۔ نیا گروپ بنانے کے لیے پروفائل مینو میں الگ آپشن استعمال کریں۔" },
    { en: "Create a new expense group. Switching between existing groups is handled separately.", hi: "नया खर्च समूह बनाएँ। मौजूदा समूह बदलने का विकल्प अलग है।", ur: "اخراجات کا نیا گروپ بنائیں۔ موجودہ گروپس کے درمیان تبدیلی الگ آپشن سے ہوگی۔" },
    { en: "New expense added", hi: "नया खर्च जोड़ा गया", ur: "نیا خرچ شامل ہوا" },
    { en: "A family member added an expense.", hi: "परिवार के सदस्य ने नया खर्च जोड़ा है।", ur: "خاندان کے رکن نے نیا خرچ شامل کیا ہے۔" },
    { en: "New expense", hi: "नया खर्च", ur: "نیا خرچ" },
    { en: "Income amount in rupees", hi: "रुपयों में आय की रकम", ur: "روپوں میں آمدنی کی رقم" },
    { en: "ZoExpense logo", hi: "ZoExpense लोगो", ur: "ZoExpense لوگو" },
    { en: "View and manage active expense records.", hi: "सक्रिय खर्च रिकॉर्ड देखें और प्रबंधित करें।", ur: "فعال اخراجات کے ریکارڈ دیکھیں اور ان کا انتظام کریں۔" },
    { en: "View income entries shared in this group.", hi: "इस समूह में साझा आय प्रविष्टियाँ देखें।", ur: "اس گروپ میں مشترکہ آمدنی کے اندراجات دیکھیں۔" },
    { en: "Restore deleted records or permanently remove them.", hi: "हटाए गए रिकॉर्ड बहाल करें या हमेशा के लिए हटाएँ।", ur: "حذف شدہ ریکارڈ بحال کریں یا مستقل طور پر حذف کریں۔" },
    { en: "Review daily totals and spending by member.", hi: "दैनिक कुल और सदस्य-वार खर्च देखें।", ur: "روزانہ کی کل رقم اور رکن کے مطابق اخراجات دیکھیں۔" },
    { en: "Compare each group member’s spending.", hi: "हर समूह सदस्य के खर्च की तुलना करें।", ur: "ہر گروپ رکن کے اخراجات کا موازنہ کریں۔" },
    { en: "Your income minus your spending", hi: "आपकी आय में से आपका खर्च घटाकर", ur: "آپ کی آمدنی میں سے آپ کا خرچ نکال کر" },
    { en: "Deleting…", hi: "हटाया जा रहा है…", ur: "حذف ہو رہا ہے…" },
    { en: "Delete income", hi: "आय हटाएँ", ur: "آمدنی حذف کریں" },
    { en: "DASHBOARD", hi: "डैशबोर्ड", ur: "ڈیش بورڈ" },
    { en: "EXPENSES", hi: "खर्च", ur: "اخراجات" },
    { en: "INCOME", hi: "आय", ur: "آمدنی" },
    { en: "DELETED EXPENSES", hi: "हटाए गए खर्च", ur: "حذف شدہ اخراجات" },
    { en: "MEMBER ANALYTICS", hi: "सदस्य विश्लेषण", ur: "رکن کے اخراجات کا تجزیہ" },
    { en: "Your family, in sync", hi: "आपका परिवार, साथ-साथ", ur: "آپ کا خاندان، ایک ساتھ" },
    { en: "ON", hi: "चालू", ur: "آن" },
    { en: "English", hi: "English", ur: "English" },
];

function uiText(lang: Lang, text: string): string {
  if (lang === 'hi' && /[\u0900-\u097f]/.test(text)) return text;
  if (lang === 'ur' && /[\u0600-\u06ff]/.test(text)) return text;
  const match = uiTranslations.find(item => item.en === text || item.hi === text || item.ur === text);
  return match ? match[lang] : text;
}

const money = (n: number) =>
  new Intl.NumberFormat('en-IN', {
    style: 'currency',
    currency: 'INR',
    maximumFractionDigits: 2,
  }).format(n);
const dateLabel = (n: number, lang: Lang) =>
  new Intl.DateTimeFormat(
    lang === 'ur' ? 'ur-PK' : uiText(lang, lang === 'hi' ? 'hi-IN' : 'en-IN'),
    { weekday: 'short', day: 'numeric', month: 'short', year: 'numeric', hour: 'numeric', minute: '2-digit' }
  ).format(n);
function messageOf(err: unknown) {
  return err instanceof Error ? err.message : 'Please try again.';
}

function playExpenseAlertSound() {
  try {
    const audio = new window.AudioContext();
    const start = audio.currentTime + 0.03;
    [880, 1174, 988].forEach((frequency, index) => {
      const oscillator = audio.createOscillator();
      const gain = audio.createGain();
      const at = start + index * 0.19;
      oscillator.type = 'triangle';
      oscillator.frequency.setValueAtTime(frequency, at);
      gain.gain.setValueAtTime(0.001, at);
      gain.gain.exponentialRampToValueAtTime(0.42, at + 0.025);
      gain.gain.exponentialRampToValueAtTime(0.001, at + 0.15);
      oscillator.connect(gain);
      gain.connect(audio.destination);
      oscillator.start(at);
      oscillator.stop(at + 0.16);
    });
    window.setTimeout(() => { void audio.close().catch(() => undefined); }, 900);
  } catch {
    // Audio can be blocked until the user has interacted with this page.
  }
}

export default function App() {
  const [user, setUser] = useState<User | null>(null);
  const [families, setFamilies] = useState<Family[]>([]);
  const [family, setFamily] = useState<Family | null>(null);
  const [familyMembers, setFamilyMembers] = useState<FamilyMember[]>([]);
  const [defaultFamilyId, setDefaultFamilyId] = useState('');
  const [expenses, setExpenses] = useState<Expense[]>([]);
  const [incomes, setIncomes] = useState<Income[]>([]);
  const [deletedExpenses, setDeletedExpenses] = useState<Expense[]>([]);
  const [activeNav, setActiveNav] = useState<MainSection>('dashboard');
  const [selectedMetric, setSelectedMetric] = useState<DashboardMetric | null>(null);
  const navStackRef = useRef<MainSection[]>([]);
  const modalHistoryRef = useRef(false);
  const skipNextPopRef = useRef(false);
  const [selectedExpense, setSelectedExpense] = useState<Expense | null>(null);
  const [nextCursor, setNextCursor] = useState<string | null>(null);
  const [lang, setLang] = useState<Lang>('hi');
  const [filter, setFilter] = useState<'all' | 'month'>('all');
  const [selectedDate, setSelectedDate] = useState('');
  const [selectedMemberId, setSelectedMemberId] = useState('all');
  const [exportPanelOpen, setExportPanelOpen] = useState(false);
  const [exporting, setExporting] = useState(false);
  const [dashboardWeekday, setDashboardWeekday] = useState('all');
  const [dashboardSearch, setDashboardSearch] = useState('');
  const [dashboardMinAmount, setDashboardMinAmount] = useState('');
  const [dashboardMaxAmount, setDashboardMaxAmount] = useState('');
  const [importPreview, setImportPreview] = useState<ImportPreviewRow[]>([]);
  const [importFileName, setImportFileName] = useState('');
  const [importing, setImporting] = useState(false);
  const [exportMode, setExportMode] = useState<'all' | 'date' | 'weekday' | 'month' | 'range'>('month');
  const [exportDate, setExportDate] = useState(() => { const d = new Date(); return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`; });
  const [exportMonth, setExportMonth] = useState(() => { const d = new Date(); return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}`; });
  const [exportFrom, setExportFrom] = useState(() => { const d = new Date(); return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-01`; });
  const [exportTo, setExportTo] = useState(() => { const d = new Date(); return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`; });
  const [exportWeekday, setExportWeekday] = useState('1');
  const [exportGroupId, setExportGroupId] = useState('current');
  const [exportMemberId, setExportMemberId] = useState('all');
  const [exportSearch, setExportSearch] = useState('');
  const [exportMinAmount, setExportMinAmount] = useState('');
  const [exportMaxAmount, setExportMaxAmount] = useState('');
  const [exportSummary, setExportSummary] = useState<{ count: number; total: number } | null>(null);
  const [dailyReportDate, setDailyReportDate] = useState(() => { const d = new Date(); return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`; });
  const [busy, setBusy] = useState(false);
  const [loading, setLoading] = useState(true);
  const [errorText, setErrorText] = useState('');
  const [modal, setModal] = useState<'expense' | 'expenseDetails' | 'editExpense' | 'income' | 'editIncome' | 'confirmDeleteIncome' | 'family' | 'createFamily' | 'editFamily' | 'invite' | 'filters' | 'import' | 'confirmDeleteExpense' | 'confirmPermanentDelete' | 'confirmDeleteGroup' | 'confirmRemoveMember' | 'metricDetails' | 'filterResults' | null>(null);
  const currentModalRef = useRef<typeof modal>(null);
  const [editingExpense, setEditingExpense] = useState<Expense | null>(null);
  const [editingFamilyId, setEditingFamilyId] = useState<string | null>(null);
  const [pendingDeleteFamily, setPendingDeleteFamily] = useState<Family | null>(null);
  const [pendingDeleteExpense, setPendingDeleteExpense] = useState<Expense | null>(null);
  const [pendingRemoveMember, setPendingRemoveMember] = useState<FamilyMember | null>(null);
  const [profileMenuOpen, setProfileMenuOpen] = useState(false);
  const [pushEnabled, setPushEnabled] = useState(false);
  const [expenseAlert, setExpenseAlert] = useState<{ id: string; title: string; body: string } | null>(null);
  const alertedExpenseIds = useRef(new Set<string>());
  const [amount, setAmount] = useState('');
  const [reason, setReason] = useState('');
  const [incomeAmount, setIncomeAmount] = useState('');
  const [incomeSource, setIncomeSource] = useState('');
  const [editingIncome, setEditingIncome] = useState<Income | null>(null);
  const [pendingDeleteIncome, setPendingDeleteIncome] = useState<Income | null>(null);
  const [familyName, setFamilyName] = useState('');
  const [inviteUrl, setInviteUrl] = useState('');
  const [pendingCode, setPendingCode] = useState<string | null>(null);
  const [inviteFamily, setInviteFamily] = useState<{
    name: string;
    familyId: string;
  } | null>(null);
  const [connection, setConnection] = useState<
    'connecting' | 'live' | 'offline'
  >('connecting');
  const connRef = useRef<ReturnType<typeof ws.connect> | null>(null);
  const t = copy[lang];
  const clearAppliedFilters = useCallback(() => {
    setFilter('all');
    setSelectedDate('');
    setSelectedMemberId('all');
    setDashboardWeekday('all');
    setDashboardSearch('');
    setDashboardMinAmount('');
    setDashboardMaxAmount('');
  }, []);
  const returnToDashboard = useCallback(() => {
    clearAppliedFilters();
    setExportPanelOpen(false);
    setSelectedMetric(null);
    setActiveNav('dashboard');
    setModal(null);
  }, [clearAppliedFilters]);
  const closeCurrentModal = useCallback(() => {
    if (modal === 'filterResults') returnToDashboard();
    else setModal(null);
  }, [modal, returnToDashboard]);
  const navigateToNav = useCallback((next: MainSection) => {
    if (next === activeNav) return;
    navStackRef.current.push(activeNav);
    window.history.pushState({ zoExpenseNav: true }, '');
    setExportPanelOpen(false);
    setActiveNav(next);
  }, [activeNav]);
  useEffect(() => {
    if (!modal) {
      currentModalRef.current = null;
      return;
    }
    currentModalRef.current = modal;
    window.history.pushState({ zoExpenseModal: true }, '');
    modalHistoryRef.current = true;
    return () => {
      if (modalHistoryRef.current && window.history.state?.zoExpenseModal) {
        modalHistoryRef.current = false;
        skipNextPopRef.current = true;
        window.history.back();
      }
    };
  }, [modal]);
  useEffect(() => {
    const handlePopState = () => {
      if (skipNextPopRef.current && !currentModalRef.current) { skipNextPopRef.current = false; return; }
      if (skipNextPopRef.current) skipNextPopRef.current = false;
      if (modalHistoryRef.current || currentModalRef.current) {
        const closingModal = currentModalRef.current;
        modalHistoryRef.current = false;
        setModal(null);
        setSelectedMetric(null);
        if (closingModal === 'filterResults') {
          clearAppliedFilters();
          setActiveNav('dashboard');
        }
        currentModalRef.current = null;
        return;
      }
      const previous = navStackRef.current.pop();
      if (previous) setActiveNav(previous);
    };
    window.addEventListener('popstate', handlePopState);
    return () => window.removeEventListener('popstate', handlePopState);
  }, [clearAppliedFilters]);
  const triggerExpenseAlert = useCallback((id: string, title: string, body: string) => {
    if (alertedExpenseIds.current.has(id)) return;
    alertedExpenseIds.current.add(id);
    setExpenseAlert({ id, title, body });
    if (typeof navigator !== 'undefined' && 'vibrate' in navigator) navigator.vibrate([240, 90, 240, 90, 480]);
    playExpenseAlertSound();
  }, []);

  useEffect(() => {
    if (!expenseAlert) return;
    const timer = window.setTimeout(() => setExpenseAlert(null), 8000);
    return () => window.clearTimeout(timer);
  }, [expenseAlert?.id]);

  useEffect(() => {
    try {
      const savedLanguage = window.localStorage.getItem('zoexpense-language');
      if (savedLanguage === 'hi' || savedLanguage === 'en' || savedLanguage === 'ur') setLang(savedLanguage);
    } catch {
      // Language preference storage may be unavailable in private browsing.
    }
  }, []);

  useEffect(() => {
    try {
      window.localStorage.setItem('zoexpense-language', lang);
    } catch {
      // Keep language switching functional even when storage is unavailable.
    }
    document.documentElement.lang = lang;
    document.documentElement.dir = uiText(lang, lang === 'ur' ? 'rtl' : 'ltr');
  }, [lang]);

  useEffect(() => {
    let active = true;
    void notifications.configure({ showSystemNotificationOnForeground: false }).catch(() => undefined);
    const unsubscribe = notifications.onMessage(payload => {
      const data = 'data' in payload ? payload.data : {};
      if (data.kind !== 'family_expense') return;
      const message = 'notification' in payload ? payload.notification : undefined;
      const expenseId = data.expenseId || `push-${Date.now()}`;
      const title = message?.title ? uiText(lang, message.title) : (lang === 'hi' ? 'नया खर्च जोड़ा गया' : uiText(lang, lang === 'ur' ? 'نیا خرچ شامل ہوا' : 'New expense added'));
      const body = message?.body ? uiText(lang, message.body) : (lang === 'hi' ? 'परिवार के सदस्य ने नया खर्च जोड़ा है।' : uiText(lang, lang === 'ur' ? 'خاندان کے رکن نے نیا خرچ شامل کیا ہے۔' : 'A family member added an expense.'));
      if (active) triggerExpenseAlert(expenseId, title, body);
    });
    if (user) {
      void notifications.getEnvironment().then(environment => {
        if (active) setPushEnabled(environment.permission === 'granted');
      }).catch(() => undefined);
    } else {
      setPushEnabled(false);
    }
    return () => { active = false; unsubscribe(); };
  }, [user?.userId, lang, triggerExpenseAlert]);

  const loadFamilies = useCallback(async (_userId?: string) => {
    const response = await api.get('/api/families');
    const list = response.data.families as Family[];
    let preferredId = '';
    try {
      const preferences = await api.get('/api/preferences');
      preferredId = String(preferences.data.defaultFamilyId || '');
    } catch (err) {
      console.error('Could not load account preferences', err);
    }
    if (preferredId && !list.some(item => item.id === preferredId)) preferredId = '';
    setDefaultFamilyId(preferredId);
    setFamilies(list);
    setFamily(current => list.find(item => item.id === current?.id) || list.find(item => item.id === preferredId) || list[0] || null);
    return list;
  }, []);

  const loadFamilyMembers = useCallback(async (familyId: string) => {
    const response = await api.get('/api/families/' + encodeURIComponent(familyId) + '/members');
    setFamilyMembers(response.data.members as FamilyMember[]);
  }, []);

  const loadIncomes = useCallback(async (familyId: string) => {
    const response = await api.get('/api/families/' + encodeURIComponent(familyId) + '/incomes');
    setIncomes((response.data as { incomes: Income[] }).incomes);
  }, []);

  useEffect(() => {
    if (!user || !family) { setIncomes([]); return; }
    let active = true;
    void api.get('/api/families/' + encodeURIComponent(family.id) + '/incomes')
      .then(response => { if (active) setIncomes((response.data as { incomes: Income[] }).incomes); })
      .catch(err => { if (active) setErrorText(messageOf(err)); });
    return () => { active = false; };
  }, [user?.userId, family?.id]);

  useEffect(() => {
    if (!user || !family) { setFamilyMembers([]); return; }
    let active = true;
    void api.get('/api/families/' + encodeURIComponent(family.id) + '/members')
      .then(response => { if (active) setFamilyMembers(response.data.members as FamilyMember[]); })
      .catch(() => { if (active) setFamilyMembers([]); });
    return () => { active = false; };
  }, [user?.userId, family?.id]);

  const setDefaultGroup = useCallback(async (item: Family) => {
    if (!user) return;
    setBusy(true);
    setErrorText('');
    try {
      await api.patch('/api/preferences', { defaultFamilyId: item.id });
      setDefaultFamilyId(item.id);
    } catch (err) {
      setErrorText(messageOf(err));
    } finally {
      setBusy(false);
    }
  }, [user?.userId]);

  const removeFamilyMember = useCallback((member: FamilyMember) => {
    if (!family || family.role !== 'owner' || member.role === 'owner') return;
    setPendingRemoveMember(member);
    setErrorText('');
    setModal('confirmRemoveMember');
  }, [family]);

  const confirmRemoveFamilyMember = useCallback(async () => {
    if (!family || family.role !== 'owner' || !pendingRemoveMember || pendingRemoveMember.role === 'owner') return;
    setBusy(true); setErrorText('');
    try {
      await api.delete('/api/families/' + encodeURIComponent(family.id) + '/members/' + encodeURIComponent(pendingRemoveMember.userId));
      setFamilyMembers(current => current.filter(item => item.userId !== pendingRemoveMember.userId));
      await loadFamilyMembers(family.id);
      setPendingRemoveMember(null);
      setModal(null);
    } catch (err) { setErrorText(messageOf(err)); }
    finally { setBusy(false); }
  }, [family, pendingRemoveMember, loadFamilyMembers]);

  const loadExpenses = useCallback(
    async (familyId: string, cursor?: string, append = false) => {
      const response = await api.get(
        '/api/families/' + encodeURIComponent(familyId) + '/expenses',
        cursor ? { cursor } : {}
      );
      const payload = response.data as {
        expenses: Expense[];
        nextCursor: string | null;
      };
      setExpenses(current =>
        append && family?.id === familyId
          ? [
              ...current,
              ...payload.expenses.filter(
                e => !current.some(old => old.id === e.id)
              ),
            ]
          : payload.expenses
      );
      setNextCursor(payload.nextCursor);
    },
    [family?.id]
  );

  const bootstrap = useCallback(async () => {
    setLoading(true);
    setErrorText('');
    try {
      const current = await auth.getUser();
      if (!current) {
        setUser(null);
        setFamilies([]);
        setFamily(null);
        setExpenses([]);
        return;
      }
      setUser(current);
      const code = invitesClient.getPendingCode();
      setPendingCode(code);
      if (code) {
        try {
          const resolved = (
            await api.get('/api/invites/' + encodeURIComponent(code))
          ).data;
          if (resolved.status === 'open' && resolved.context?.familyId)
            setInviteFamily({
              name: String(resolved.context.familyName || 'Family'),
              familyId: String(resolved.context.familyId),
            });
          else
            setErrorText('This invitation is expired or no longer available.');
        } catch (err) {
          setErrorText(messageOf(err));
        }
      }
      const list = await loadFamilies(current.userId);
      if (list.length === 0 && !code) setModal('family');
    } catch (err) {
      setErrorText(messageOf(err));
    } finally {
      setLoading(false);
    }
  }, [loadFamilies]);

  useEffect(() => {
    void bootstrap();
  }, [bootstrap]);
  useEffect(() => {
    if (!user || !family) {
      setExpenses([]);
      return;
    }
    let active = true;
    setConnection('connecting');
    void loadExpenses(family.id).catch(err => {
      if (active) setErrorText(messageOf(err));
    });
    const conn = connRef.current || ws.connect();
    connRef.current = conn;
    const onMessage = (message: {
      type?: string;
      payload?: {
        entity_type?: string;
        entity_id?: string;
        data?: { action?: string; expense?: Expense; expenseId?: string };
      };
    }) => {
      if (
        !active ||
        message.type !== 'entity.update' ||
        message.payload?.entity_type !== 'family_expenses' ||
        message.payload.entity_id !== family.id
      )
        return;
      const data = message.payload.data;
      if (data?.action === 'created' && data.expense) {
        if (data.expense.creatorId !== user.userId) {
          triggerExpenseAlert(
            data.expense.id,
            lang === 'hi' ? 'नया खर्च जोड़ा गया' : uiText(lang, lang === 'ur' ? 'نیا خرچ شامل ہوا' : 'New expense added'),
            `${data.expense.creatorName} · ${data.expense.reason} · ${money(data.expense.amount)}`
          );
        }
        setExpenses(current => current.some(e => e.id === data.expense!.id) ? current : [data.expense!, ...current]);
      }
      if (data?.action === 'updated' && data.expense)
        setExpenses(current => current.map(expense => expense.id === data.expense!.id ? data.expense! : expense));
      if (data?.action === 'deleted' && data.expenseId)
        setExpenses(current => current.filter(e => e.id !== data.expenseId));
    };
    conn.onMessage(onMessage);
    conn.onError(() => {
      if (active) setConnection('offline');
    });
    conn.onClose(() => {
      if (active) setConnection('offline');
    });
    conn.ready
      .then(async () => {
        if (!active || !conn.connectionId) return;
        try {
          await api.post(
            '/api/families/' + encodeURIComponent(family.id) + '/subscriptions',
            { connection_id: conn.connectionId }
          );
          if (active) setConnection('live');
        } catch {
          if (active) setConnection('offline');
        }
      })
      .catch(() => {
        if (active) setConnection('offline');
      });
    return () => {
      active = false;
      if (conn.connectionId)
        void api
          .delete(
            '/api/families/' + encodeURIComponent(family.id) + '/subscriptions',
            { connection_id: conn.connectionId }
          )
          .catch(() => undefined);
    };
  }, [user?.userId, family?.id, loadExpenses, lang, triggerExpenseAlert]);

  const baseVisibleExpenses = useMemo(() => {
    const now = new Date();
    const min = dashboardMinAmount.trim() ? Number(dashboardMinAmount) : null;
    const max = dashboardMaxAmount.trim() ? Number(dashboardMaxAmount) : null;
    const query = dashboardSearch.trim().toLocaleLowerCase();
    return expenses.filter(expense => {
      const d = new Date(expense.createdAt);
      const localDate = [d.getFullYear(), String(d.getMonth() + 1).padStart(2, '0'), String(d.getDate()).padStart(2, '0')].join('-');
      if (selectedDate && localDate !== selectedDate) return false;
      if (!selectedDate && filter === 'month' && !(d.getFullYear() === now.getFullYear() && d.getMonth() === now.getMonth())) return false;
      if (dashboardWeekday !== 'all' && d.getDay() !== Number(dashboardWeekday)) return false;
      if (min !== null && Number.isFinite(min) && expense.amount < min) return false;
      if (max !== null && Number.isFinite(max) && expense.amount > max) return false;
      if (query && !(expense.reason + ' ' + expense.creatorName).toLocaleLowerCase().includes(query)) return false;
      return true;
    });
  }, [expenses, filter, selectedDate, dashboardWeekday, dashboardMinAmount, dashboardMaxAmount, dashboardSearch]);
  const visibleExpenses = useMemo(
    () => baseVisibleExpenses.filter(expense => selectedMemberId === 'all' || expense.creatorId === selectedMemberId),
    [baseVisibleExpenses, selectedMemberId]
  );
  const memberSummaries = useMemo(() => {
    const summary = new Map<string, { id: string; name: string; picture?: string; amount: number; count: number }>();
    for (const expense of baseVisibleExpenses) {
      const current = summary.get(expense.creatorId) || {
        id: expense.creatorId, name: expense.creatorName, picture: expense.creatorPicture, amount: 0, count: 0
      };
      current.amount += expense.amount;
      current.count += 1;
      if (!current.picture && expense.creatorPicture) current.picture = expense.creatorPicture;
      summary.set(expense.creatorId, current);
    }
    return [...summary.values()].sort((a, b) => b.amount - a.amount);
  }, [baseVisibleExpenses]);
  const allMemberSummaries = useMemo(() => {
    const summary = new Map<string, { id: string; name: string; picture?: string; amount: number; count: number }>();
    for (const expense of expenses) {
      const current = summary.get(expense.creatorId) || {
        id: expense.creatorId, name: expense.creatorName, picture: expense.creatorPicture, amount: 0, count: 0
      };
      current.amount += expense.amount;
      current.count += 1;
      if (!current.picture && expense.creatorPicture) current.picture = expense.creatorPicture;
      summary.set(expense.creatorId, current);
    }
    return [...summary.values()].sort((a, b) => b.amount - a.amount);
  }, [expenses]);
  const dailyExpenses = useMemo(() => expenses.filter(expense => {
    const d = new Date(expense.createdAt);
    const key = `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
    return key === dailyReportDate;
  }), [expenses, dailyReportDate]);
  const dailyTotal = dailyExpenses.reduce((sum, expense) => sum + expense.amount, 0);
  const dailyMemberSummaries = useMemo(() => {
    const summary = new Map<string, { id: string; name: string; picture?: string; amount: number; count: number }>();
    for (const expense of dailyExpenses) {
      const current = summary.get(expense.creatorId) || {
        id: expense.creatorId, name: expense.creatorName, picture: expense.creatorPicture, amount: 0, count: 0
      };
      current.amount += expense.amount;
      current.count += 1;
      if (!current.picture && expense.creatorPicture) current.picture = expense.creatorPicture;
      summary.set(expense.creatorId, current);
    }
    return [...summary.values()].sort((a, b) => b.amount - a.amount);
  }, [dailyExpenses]);
  useEffect(() => {
    if ((!selectedDate && !dailyReportDate) || !family?.id) return;
    let active = true;
    const familyId = family.id;
    async function loadFullDateHistory() {
      try {
        const allExpenses: Expense[] = [];
        let cursor: string | undefined;
        do {
          const response = await api.get(
            '/api/families/' + encodeURIComponent(familyId) + '/expenses',
            cursor ? { cursor } : {}
          );
          const payload = response.data as { expenses: Expense[]; nextCursor: string | null };
          allExpenses.push(...payload.expenses);
          cursor = payload.nextCursor || undefined;
        } while (cursor && active);
        if (active) {
          setExpenses(current => {
            const freshRealtime = current.filter(item =>
              item.familyId === familyId && !allExpenses.some(expense => expense.id === item.id)
            );
            return [...allExpenses, ...freshRealtime].sort((a, b) => b.createdAt - a.createdAt);
          });
        }
      } catch (err) {
        if (active) setErrorText(messageOf(err));
      }
    }
    void loadFullDateHistory();
    return () => { active = false; };
  }, [selectedDate, dailyReportDate, family?.id]);

  const monthTotal = useMemo(
    () =>
      expenses
        .filter(e => {
          const d = new Date(e.createdAt),
            n = new Date();
          return (
            d.getFullYear() === n.getFullYear() && d.getMonth() === n.getMonth()
          );
        })
        .reduce((sum, e) => sum + e.amount, 0),
    [expenses]
  );
  const total = expenses.reduce((sum, e) => sum + e.amount, 0);
  const monthIncome = useMemo(() => { const now = new Date(); return incomes.filter(item => { const date = new Date(item.createdAt); return date.getFullYear() === now.getFullYear() && date.getMonth() === now.getMonth(); }).reduce((sum, item) => sum + item.amount, 0); }, [incomes]);
  const totalIncome = incomes.reduce((sum, item) => sum + item.amount, 0);
  const remainingBalance = totalIncome - total;
  const myIncomes = useMemo(() => incomes.filter(item => item.creatorId === user?.userId), [incomes, user?.userId]);
  const myExpenses = useMemo(() => expenses.filter(item => item.creatorId === user?.userId), [expenses, user?.userId]);
  const myTotalIncome = myIncomes.reduce((sum, item) => sum + item.amount, 0);
  const myTotalSpent = myExpenses.reduce((sum, item) => sum + item.amount, 0);
  const myMonthIncome = useMemo(() => { const now = new Date(); return myIncomes.filter(item => { const date = new Date(item.createdAt); return date.getFullYear() === now.getFullYear() && date.getMonth() === now.getMonth(); }).reduce((sum, item) => sum + item.amount, 0); }, [myIncomes]);
  const myMonthSpent = useMemo(() => { const now = new Date(); return myExpenses.filter(item => { const date = new Date(item.createdAt); return date.getFullYear() === now.getFullYear() && date.getMonth() === now.getMonth(); }).reduce((sum, item) => sum + item.amount, 0); }, [myExpenses]);
  const myRemainingBalance = myTotalIncome - myTotalSpent;
  const metricLabels: Record<DashboardMetric, string> = { familyIncome: uiText(lang, 'All family income'), familyMonthIncome: uiText(lang, 'All family this month income'), myIncome: uiText(lang, 'Your total income'), myMonthIncome: uiText(lang, 'Your this month income'), mySpent: uiText(lang, 'Your total spent'), myMonthSpent: uiText(lang, 'Your this month spent'), familySpent: uiText(lang, 'All family total spent'), familyMonthSpent: uiText(lang, 'All family this month spent'), myBalance: uiText(lang, 'Your remaining balance'), allExpenses: uiText(lang, 'All expenses') };
  const metricValues: Record<DashboardMetric, number> = { familyIncome: totalIncome, familyMonthIncome: monthIncome, myIncome: myTotalIncome, myMonthIncome, mySpent: myTotalSpent, myMonthSpent, familySpent: total, familyMonthSpent: monthTotal, myBalance: myRemainingBalance, allExpenses: total };
  const openMetricDetails = (metric: DashboardMetric) => { setSelectedMetric(metric); setModal('metricDetails'); };
  const incomeMemberSummaries = useMemo(() => {
    const summary = new Map<string, { id: string; name: string; picture?: string; income: number; spending: number; incomeCount: number }>();
    for (const member of familyMembers) summary.set(member.userId, { id: member.userId, name: member.name, income: 0, spending: 0, incomeCount: 0 });
    for (const item of incomes) { const current = summary.get(item.creatorId) || { id: item.creatorId, name: item.creatorName, picture: item.creatorPicture, income: 0, spending: 0, incomeCount: 0 }; current.income += item.amount; current.incomeCount += 1; if (!current.picture && item.creatorPicture) current.picture = item.creatorPicture; current.name = current.name || item.creatorName; summary.set(item.creatorId, current); }
    for (const item of expenses) { const current = summary.get(item.creatorId) || { id: item.creatorId, name: item.creatorName, picture: item.creatorPicture, income: 0, spending: 0, incomeCount: 0 }; current.spending += item.amount; if (!current.picture && item.creatorPicture) current.picture = item.creatorPicture; current.name = current.name || item.creatorName; summary.set(item.creatorId, current); }
    return [...summary.values()].sort((x, y) => y.income - x.income);
  }, [familyMembers, incomes, expenses]);
  const exportText = lang === 'hi' ? { title: 'रिपोर्ट और एक्सपोर्ट', subtitle: 'तारीख, दिन, महीने, समूह और सदस्य के अनुसार डेटा चुनें।', period: 'अवधि', all: 'सभी तारीखें', date: 'एक तारीख', weekday: 'सप्ताह का दिन', month: 'महीना', range: 'तारीख सीमा', group: 'समूह', allGroups: 'सभी समूह', current: 'वर्तमान समूह', member: 'सदस्य', allMembers: 'सभी सदस्य', from: 'से तारीख', to: 'तक तारीख', search: 'खर्च या सदस्य खोजें', min: 'न्यूनतम रकम ₹', max: 'अधिकतम रकम ₹', weekdays: ['रविवार','सोमवार','मंगलवार','बुधवार','गुरुवार','शुक्रवार','शनिवार'], last: 'पिछला एक्सपोर्ट', count: 'खर्च', total: 'कुल रकम', xlsx: 'Excel डाउनलोड', pdf: 'PDF डाउनलोड', noData: 'इन फिल्टर के लिए कोई खर्च नहीं मिला।', invalid: 'तारीख सीमा या रकम की जाँच करें।', loading: 'रिपोर्ट तैयार हो रही है…' } : lang === 'ur' ? { title: 'رپورٹ اور ایکسپورٹ', subtitle: 'تاریخ، دن، ماہ، گروپ اور رکن کے مطابق ڈیٹا منتخب کریں۔', period: 'مدت', all: 'تمام تاریخیں', date: 'ایک تاریخ', weekday: 'ہفتے کا دن', month: 'مہینہ', range: 'تاریخ کی حد', group: 'گروپ', allGroups: 'تمام گروپس', current: 'موجودہ گروپ', member: 'رکن', allMembers: 'تمام اراکین', from: 'شروع کی تاریخ', to: 'آخری تاریخ', search: 'خرچ یا رکن تلاش کریں', min: 'کم از کم رقم ₹', max: 'زیادہ سے زیادہ رقم ₹', weekdays: ['اتوار','پیر','منگل','بدھ','جمعرات','جمعہ','ہفتہ'], last: 'پچھلا ایکسپورٹ', count: 'اخراجات', total: 'کل رقم', xlsx: 'Excel ڈاؤن لوڈ', pdf: 'PDF ڈاؤن لوڈ', noData: 'ان فلٹرز کے لیے کوئی خرچ نہیں ملا۔', invalid: 'تاریخ کی حد یا رقم درست کریں۔', loading: 'رپورٹ تیار ہو رہی ہے…' } : { title: 'Reports & export', subtitle: 'Choose the exact period, group and member. Only matching expenses are included.', period: 'Period', all: 'All dates', date: 'Single date', weekday: 'Day of week', month: 'Month', range: 'Date range', group: 'Group', allGroups: 'All groups', current: 'Current group', member: 'Member', allMembers: 'All members', from: 'From date', to: 'To date', search: 'Search expense or member', min: 'Minimum amount ₹', max: 'Maximum amount ₹', weekdays: ['Sunday','Monday','Tuesday','Wednesday','Thursday','Friday','Saturday'], last: 'Last export', count: 'expenses', total: 'Total', xlsx: 'Export Excel', pdf: 'Export PDF', noData: 'No expenses match these filters.', invalid: 'Check the date range and amount limits.', loading: 'Preparing report…' };

  async function exportSelectedData(format: 'xlsx' | 'pdf') {
    if (!family || exporting) return;
    setExporting(true);
    setErrorText('');
    try {
      if (exportMode === 'range' && (!exportFrom || !exportTo || exportFrom > exportTo)) throw new Error(exportText.invalid);
      const min = exportMinAmount.trim() ? Number(exportMinAmount) : null;
      const max = exportMaxAmount.trim() ? Number(exportMaxAmount) : null;
      if ((min !== null && (!Number.isFinite(min) || min < 0)) || (max !== null && (!Number.isFinite(max) || max < 0)) || (min !== null && max !== null && min > max)) throw new Error(exportText.invalid);
      const groups = exportGroupId === 'all' ? families : [exportGroupId === 'current' ? family : families.find(item => item.id === exportGroupId)].filter((item): item is Family => Boolean(item));
      if (!groups.length) throw new Error('Choose a group to export.');
      const names = new Map(groups.map(item => [item.id, item.name]));
      const records: Expense[] = [];
      for (const item of groups) {
        let cursor: string | undefined;
        const seen = new Set<string>();
        do {
          const response = await api.get('/api/families/' + encodeURIComponent(item.id) + '/expenses', cursor ? { cursor } : {});
          const payload = response.data as { expenses: Expense[]; nextCursor: string | null };
          records.push(...payload.expenses.map(expense => ({ ...expense, familyId: expense.familyId || item.id })));
          const next = payload.nextCursor || undefined;
          if (next && seen.has(next)) throw new Error('Expense history pagination did not advance. Please retry.');
          if (next) seen.add(next);
          cursor = next;
        } while (cursor);
      }
      const dateKey = (stamp: number) => { const d = new Date(stamp); return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`; };
      const query = exportSearch.trim().toLocaleLowerCase();
      const filtered = records.filter(expense => {
        const d = new Date(expense.createdAt), key = dateKey(expense.createdAt);
        if (exportMode === 'date' && key !== exportDate) return false;
        if (exportMode === 'weekday' && d.getDay() !== Number(exportWeekday)) return false;
        if (exportMode === 'month' && !key.startsWith(exportMonth)) return false;
        if (exportMode === 'range' && (key < exportFrom || key > exportTo)) return false;
        if (exportMemberId !== 'all' && expense.creatorId !== exportMemberId) return false;
        if (min !== null && expense.amount < min) return false;
        if (max !== null && expense.amount > max) return false;
        const groupName = names.get(expense.familyId) || families.find(item => item.id === expense.familyId)?.name || '';
        if (query && !(expense.reason + ' ' + expense.creatorName + ' ' + groupName).toLocaleLowerCase().includes(query)) return false;
        return true;
      }).sort((a, b) => a.createdAt - b.createdAt);
      if (!filtered.length) throw new Error(exportText.noData);
      const sum = filtered.reduce((value, expense) => value + expense.amount, 0);
      setExportSummary({ count: filtered.length, total: sum });
      const rows = filtered.map((expense, index) => { const d = new Date(expense.createdAt); return { 'Sr. No.': index + 1, Group: names.get(expense.familyId) || families.find(item => item.id === expense.familyId)?.name || 'Group', Date: dateKey(expense.createdAt), Day: new Intl.DateTimeFormat('en-IN', { weekday: 'long' }).format(d), Time: new Intl.DateTimeFormat('en-IN', { hour: '2-digit', minute: '2-digit', hour12: true }).format(d), Expense: expense.reason, 'Added by': expense.creatorName, 'Amount (INR)': expense.amount }; });
      const periodName = exportMode === 'date' ? exportDate : exportMode === 'month' ? exportMonth : exportMode === 'range' ? exportFrom + '-to-' + exportTo : exportMode === 'weekday' ? exportText.weekdays[Number(exportWeekday)] : 'all-dates';
      const filename = ('ZoExpense-' + periodName).replace(/[^a-z0-9-_]+/gi, '-');
      if (format === 'xlsx') {
        const book = XLSX.utils.book_new();
        const detail = XLSX.utils.json_to_sheet(rows);
        detail['!cols'] = [{ wch: 9 }, { wch: 22 }, { wch: 13 }, { wch: 14 }, { wch: 13 }, { wch: 32 }, { wch: 24 }, { wch: 16 }];
        XLSX.utils.book_append_sheet(book, detail, 'Expenses');
        const members = new Map<string, { count: number; amount: number }>();
        for (const item of filtered) { const key = item.creatorName || 'Unknown'; const v = members.get(key) || { count: 0, amount: 0 }; v.count += 1; v.amount += item.amount; members.set(key, v); }
        const summary = [['ZoExpense report'], ['Generated at', new Date().toLocaleString()], ['Expense count', filtered.length], ['Total amount (INR)', sum], ['Groups included', new Set(filtered.map(item => item.familyId)).size], [], ['Family member', 'Expense count', 'Total amount (INR)'], ...[...members.entries()].sort((a,b) => b[1].amount-a[1].amount).map(([name, v]) => [name, v.count, v.amount])];
        const summarySheet = XLSX.utils.aoa_to_sheet(summary);
        summarySheet['!cols'] = [{ wch: 30 }, { wch: 18 }, { wch: 22 }];
        XLSX.utils.book_append_sheet(book, summarySheet, 'Summary');
        XLSX.writeFile(book, filename + '.xlsx');
      } else {
        const doc = new jsPDF({ orientation: 'landscape', unit: 'mm', format: 'a4' });
        doc.setFontSize(18); doc.setTextColor(22, 61, 49); doc.text('ZoExpense - Expense Report', 14, 17);
        doc.setFontSize(9); doc.setTextColor(90, 110, 102); doc.text(`Period: ${periodName} | Expenses: ${filtered.length} | Total: INR ${sum.toFixed(2)}`, 14, 24);
        autoTable(doc, { startY: 30, head: [['#', 'Group', 'Date', 'Day', 'Time', 'Expense', 'Added by', 'Amount (INR)']], body: rows.map(row => [row['Sr. No.'], row.Group, row.Date, row.Day, row.Time, row.Expense, row['Added by'], row['Amount (INR)'].toFixed(2)]), styles: { fontSize: 7.5, cellPadding: 2.4, overflow: 'linebreak' }, headStyles: { fillColor: [23, 107, 80], textColor: 255 }, alternateRowStyles: { fillColor: [244, 249, 246] }, columnStyles: { 0: { cellWidth: 9 }, 1: { cellWidth: 28 }, 2: { cellWidth: 23 }, 3: { cellWidth: 23 }, 4: { cellWidth: 18 }, 5: { cellWidth: 'auto' }, 6: { cellWidth: 35 }, 7: { cellWidth: 25, halign: 'right' } }, margin: { left: 12, right: 12 } });
        const pages = doc.getNumberOfPages();
        for (let page = 1; page <= pages; page += 1) { doc.setPage(page); doc.setFontSize(8); doc.setTextColor(120, 135, 128); doc.text(`ZoExpense · Page ${page} of ${pages}`, 14, 202); }
        doc.save(filename + '.pdf');
      }
      setExportPanelOpen(false);
    } catch (err) { setErrorText(messageOf(err)); }
    finally { setExporting(false); }
  }

  async function signIn() {
    setErrorText('');
    try {
      const result = await auth.signIn();
      setUser(result.user);
      await bootstrap();
    } catch (err) {
      setErrorText(messageOf(err));
    }
  }
  async function togglePushNotifications() {
    setErrorText('');
    try {
      if (pushEnabled) {
        await notifications.unsubscribe();
        setPushEnabled(false);
      } else {
        await notifications.subscribe();
        setPushEnabled(true);
      }
    } catch (err) {
      setErrorText(messageOf(err));
    }
  }

  async function signOut() {
    try {
      if (connRef.current) {
        connRef.current.disconnect();
        connRef.current = null;
      }
      await auth.signOut();
      setUser(null);
      setFamily(null);
      setFamilies([]);
      setExpenses([]);
    } catch (err) {
      setErrorText(messageOf(err));
    }
  }
  async function createFamily(e: React.FormEvent) {
    e.preventDefault();
    if (!familyName.trim()) return;
    setBusy(true);
    setErrorText('');
    try {
      if (editingFamilyId) {
        const response = await api.patch('/api/families/' + encodeURIComponent(editingFamilyId), { name: familyName.trim() });
        const updated = response.data.family as Family;
        const list = await loadFamilies(user?.userId);
        setFamilies(list.map(item => item.id === updated.id ? updated : item));
        setFamily(current => current?.id === updated.id ? updated : current);
        setEditingFamilyId(null);
        setFamilyName('');
      } else {
        const response = await api.post('/api/families', { name: familyName.trim() });
        const created = response.data.family as Family;
        const list = await loadFamilies(user?.userId);
        setFamily(created);
        setFamilies(list);
        setFamilyName('');
      }
      setModal(null);
    } catch (err) {
      setErrorText(messageOf(err));
    } finally {
      setBusy(false);
    }
  }
  async function deleteFamily(item: Family) {
    if (item.role !== 'owner') return;
    setPendingDeleteFamily(item);
    setErrorText('');
    setModal('confirmDeleteGroup');
  }

  async function confirmDeleteFamily() {
    const item = pendingDeleteFamily;
    if (!item || item.role !== 'owner' || busy) return;
    setBusy(true);
    setErrorText('');
    try {
      await api.delete('/api/families/' + encodeURIComponent(item.id));
      const remaining = families.filter(existing => existing.id !== item.id);
      if (defaultFamilyId === item.id && user) {
        try { window.localStorage.removeItem('zoexpense-default-group:' + user.userId); } catch { /* ignore */ }
        setDefaultFamilyId('');
      }
      setFamilies(remaining);
      setEditingFamilyId(null);
      setFamilyName('');
      if (family?.id === item.id) {
        const next = remaining[0] || null;
        setFamily(next);
        if (!next) setExpenses([]);
      }
      setPendingDeleteFamily(null);
      setModal(null);
    } catch (err) {
      setErrorText(messageOf(err));
    } finally {
      setBusy(false);
    }
  }

  async function handleImportFile(file?: File) {
    if (!file) return;
    setImportFileName(file.name);
    setImportPreview([]);
    setErrorText('');
    try {
      const workbook = XLSX.read(await file.arrayBuffer(), { type: 'array' });
      const firstSheet = workbook.SheetNames[0];
      if (!firstSheet) throw new Error(uiText(lang, lang === 'hi' ? 'फ़ाइल में कोई शीट नहीं मिली।' : 'No worksheet found.'));
      const rows = XLSX.utils.sheet_to_json<Record<string, unknown>>(workbook.Sheets[firstSheet], { defval: '' });
      if (!rows.length) throw new Error(uiText(lang, lang === 'hi' ? 'फ़ाइल खाली है।' : 'The file is empty.'));
      const normalize = (value: unknown) => String(value ?? '').trim().toLocaleLowerCase().replace(/[_-]+/g, ' ').replace(/\s+/g, ' ');
      const pick = (row: Record<string, unknown>, keys: string[]) => {
        const entries = Object.entries(row);
        for (const key of keys) {
          const match = entries.find(([name]) => normalize(name) === key || normalize(name).includes(key));
          if (match && String(match[1] ?? '').trim() !== '') return match[1];
        }
        return '';
      };
      const preview = rows.slice(0, 2000).map((row, index) => {
        const rawAmount = String(pick(row, ['amount', 'amt', 'रकम', 'total', 'price']) ?? '').replace(/[₹,\s]/g, '');
        const value = Number(rawAmount);
        const reasonValue = String(pick(row, ['reason', 'expense', 'description', 'particular', 'item', 'विवरण', 'खर्च']) ?? '').trim();
        const issue = !Number.isFinite(value) || value <= 0 ? (uiText(lang, lang === 'hi' ? 'रकम सही नहीं है' : 'Invalid amount')) : !reasonValue ? (uiText(lang, lang === 'hi' ? 'खर्च का विवरण नहीं है' : 'Missing expense description')) : undefined;
        return { rowNumber: index + 2, amount: value, reason: reasonValue, error: issue } as ImportPreviewRow;
      });
      setImportPreview(preview);
      if (rows.length > 2000) setErrorText(uiText(lang, lang === 'hi' ? 'पहली 2,000 पंक्तियाँ ही दिखाई जा रही हैं।' : 'Only the first 2,000 rows are previewed.'));
    } catch (err) {
      setErrorText(messageOf(err));
    }
  }

  async function importSelectedExpenses() {
    if (!family || !user || importing) return;
    const validRows = importPreview.filter(row => !row.error);
    if (!validRows.length) {
      setErrorText(uiText(lang, lang === 'hi' ? 'इम्पोर्ट करने के लिए सही पंक्तियाँ नहीं हैं।' : 'There are no valid rows to import.'));
      return;
    }
    setImporting(true);
    setErrorText('');
    let imported = 0;
    let failed = 0;
    try {
      const endpoint = '/api/families/' + encodeURIComponent(family.id) + '/expenses';
      for (const row of validRows) {
        try {
          await api.post(endpoint, { amount: row.amount, reason: row.reason, creatorPicture: user.picture });
          imported += 1;
        } catch {
          failed += 1;
        }
      }
      await loadExpenses(family.id);
      setModal(null);
      setImportPreview([]);
      setImportFileName('');
      setErrorText(lang === 'hi' ? 'इम्पोर्ट पूरा: ' + imported + ' सफल, ' + failed + ' असफल।' : 'Import complete: ' + imported + ' added, ' + failed + ' failed.');
    } catch (err) {
      setErrorText(messageOf(err));
    } finally {
      setImporting(false);
    }
  }

  function openIncomeEdit(income: Income) {
    setEditingIncome(income); setIncomeAmount(String(income.amount)); setIncomeSource(income.source); setErrorText(''); setModal('editIncome');
  }
  async function saveIncome(e: React.FormEvent) {
    e.preventDefault();
    if (!family) return;
    const value = Number(incomeAmount); const source = incomeSource.trim();
    if (!Number.isFinite(value) || value <= 0 || value > 100000000 || !source) { setErrorText(uiText(lang, lang === 'hi' ? 'कृपया सही आय और उसका स्रोत भरें।' : 'Enter a valid income amount and source.')); return; }
    setBusy(true); setErrorText('');
    try {
      const baseUrl = '/api/families/' + encodeURIComponent(family.id) + '/incomes';
      const response = modal === 'editIncome' && editingIncome ? await api.patch(baseUrl + '/' + encodeURIComponent(editingIncome.id), { amount: value, source }) : await api.post(baseUrl, { amount: value, source, creatorPicture: user?.picture });
      const saved = response.data.income as Income;
      setIncomes(current => modal === 'editIncome' ? current.map(item => item.id === saved.id ? saved : item) : [saved, ...current.filter(item => item.id !== saved.id)]);
      setIncomeAmount(''); setIncomeSource(''); setEditingIncome(null); setModal(null); setActiveNav('income');
    } catch (err) { setErrorText(messageOf(err)); }
    finally { setBusy(false); }
  }
  async function confirmDeleteIncome() {
    const income = pendingDeleteIncome;
    if (!family || !income || busy) return;
    setBusy(true); setErrorText('');
    try {
      await api.delete('/api/families/' + encodeURIComponent(family.id) + '/incomes/' + encodeURIComponent(income.id));
      setIncomes(current => current.filter(item => item.id !== income.id)); setPendingDeleteIncome(null); setModal(null);
    } catch (err) { setErrorText(messageOf(err)); }
    finally { setBusy(false); }
  }

  function openExpenseEdit(expense: Expense) {
    setEditingExpense(expense);
    setAmount(String(expense.amount));
    setReason(expense.reason);
    setErrorText('');
    setModal('editExpense');
  }
  async function saveExpense(e: React.FormEvent) {
    e.preventDefault();
    if (!family) return;
    const value = Number(amount);
    if (!Number.isFinite(value) || value <= 0 || !reason.trim()) {
      setErrorText('कृपया सही रकम और खर्च का कारण भरें।');
      return;
    }
    setBusy(true);
    setErrorText('');
    try {
      const baseUrl = '/api/families/' + encodeURIComponent(family.id) + '/expenses';
      const response = modal === 'editExpense' && editingExpense
        ? await api.patch(baseUrl + '/' + encodeURIComponent(editingExpense.id), { amount: value, reason: reason.trim() })
        : await api.post(baseUrl, { amount: value, reason: reason.trim(), creatorPicture: user?.picture });
      const saved = response.data.expense as Expense;
      setExpenses(current => modal === 'editExpense'
        ? current.map(expense => expense.id === saved.id ? saved : expense)
        : current.some(expense => expense.id === saved.id) ? current : [saved, ...current]);
      setModal(null);
      setAmount('');
      setReason('');
      setEditingExpense(null);
    } catch (err) {
      setErrorText(messageOf(err));
    } finally {
      setBusy(false);
    }
  }
  async function deleteExpense(expense: Expense) {
    if (!family) return;
    setPendingDeleteExpense(expense);
    setErrorText('');
    setModal('confirmDeleteExpense');
  }

  async function confirmDeleteExpense() {
    const expense = pendingDeleteExpense;
    if (!family || !expense || busy) return;
    setBusy(true);
    setErrorText('');
    try {
      await api.delete('/api/families/' + encodeURIComponent(family.id) + '/expenses/' + encodeURIComponent(expense.id));
      setExpenses(current => current.filter(item => item.id !== expense.id));
      setDeletedExpenses(current => [ { ...expense, deletedAt: Date.now() }, ...current.filter(item => item.id !== expense.id) ]);
      setPendingDeleteExpense(null);
      setModal(null);
    } catch (err) {
      setErrorText(messageOf(err));
    } finally {
      setBusy(false);
    }
  }

  async function restoreExpense(expense: Expense) {
    if (!family || busy) return;
    setBusy(true);
    setErrorText('');
    try {
      await api.post('/api/families/' + encodeURIComponent(family.id) + '/expenses/' + encodeURIComponent(expense.id) + '/restore', {});
      setDeletedExpenses(current => current.filter(item => item.id !== expense.id));
      setExpenses(current => [ { ...expense, deletedAt: undefined }, ...current.filter(item => item.id !== expense.id) ].sort((a, b) => b.createdAt - a.createdAt));
    } catch (err) { setErrorText(messageOf(err)); }
    finally { setBusy(false); }
  }

  async function permanentlyDeleteExpense() {
    const expense = pendingDeleteExpense;
    if (!family || !expense || busy) return;
    setBusy(true);
    setErrorText('');
    try {
      await api.delete('/api/families/' + encodeURIComponent(family.id) + '/expenses/' + encodeURIComponent(expense.id) + '/permanent');
      setDeletedExpenses(current => current.filter(item => item.id !== expense.id));
      setPendingDeleteExpense(null);
      setModal(null);
    } catch (err) { setErrorText(messageOf(err)); }
    finally { setBusy(false); }
  }

  async function createInvite() {
    if (!family) return;
    setBusy(true);
    setErrorText('');
    try {
      const result = (
        await api.post(
          '/api/families/' + encodeURIComponent(family.id) + '/invites'
        )
      ).data;
      const url = invitesClient.buildJoinUrl(result.code, { path: '#/join' });
      setInviteUrl(url);
      setModal('invite');
    } catch (err) {
      setErrorText(messageOf(err));
    } finally {
      setBusy(false);
    }
  }
  async function joinFamily() {
    if (!pendingCode) return;
    setBusy(true);
    setErrorText('');
    try {
      await api.post(
        '/api/invites/' + encodeURIComponent(pendingCode) + '/join'
      );
      invitesClient.clearPendingCode();
      setPendingCode(null);
      setInviteFamily(null);
      const list = await loadFamilies(user?.userId);
      const joined = list.find(f => f.id === inviteFamily?.familyId);
      if (joined) setFamily(joined);
    } catch (err) {
      setErrorText(messageOf(err));
    } finally {
      setBusy(false);
    }
  }

  if (loading)
    return (
      <div className="splash">
        <div className="brand-mark splash-logo">
          <img src="/resources/zoexpense-logo.png" alt={uiText(lang, 'ZoExpense logo')} />
        </div>
        <p className="splash-title">ZoExpense</p>
        <span>आपके परिवार के खर्च साथ-साथ</span>
      </div>
    );
  if (!user)
    return (
      <main className="login-shell">
        <div className="login-card">
          <div className="brand-lockup">
            <div className="brand-mark">
              <img src="/resources/zoexpense-logo.png" alt={uiText(lang, 'ZoExpense logo')} />
            </div>
            <div>
              <strong>ZoExpense</strong>
              <small>{uiText(lang, 'FAMILY FINANCES')}</small>
            </div>
          </div>
          <div className="login-art">
            <div className="art-circle">
              <IndianRupee size={38} />
            </div>
            <div className="art-mini mini-one">
              <ArrowUpRight size={18} />
              <span>घर का खर्च</span>
            </div>
            <div className="art-mini mini-two">
              <Check size={18} />
              <span>सब एक जगह</span>
            </div>
          </div>
          <p className="eyebrow">{uiText(lang, 'FAMILY FINANCES')}</p>
          <h1>{t.signIn}</h1>
          <p className="muted">{t.signInText}</p>
          {errorText && <div className="alert">{uiText(lang, errorText)}</div>}
          <button className="primary wide" onClick={signIn}>
            {t.signIn} <ArrowUpRight size={17} />
          </button>
          <p className="tiny">
            <ShieldCheck size={14} /> सुरक्षित साइन-इन · निजी पारिवारिक डेटा
          </p>
          <LanguageSelect lang={lang} setLang={setLang} />
        </div>
      </main>
    );

  return (
    <div dir={uiText(lang, lang === 'ur' ? 'rtl' : 'ltr')} className={uiText(lang, lang === 'ur' ? 'app-shell rtl' : 'app-shell')}>
      <aside className="sidebar">
        <div className="brand-lockup">
          <div className="brand-mark">
            <img src="/resources/zoexpense-logo.png" alt={uiText(lang, 'ZoExpense logo')} />
          </div>
          <div className="brand-title">
            <strong>ZoExpense</strong>
            <small>{uiText(lang, 'FAMILY FINANCES')}</small>
          </div>
        </div>
        <div className="side-label nav-heading">{uiText(lang, 'WORKSPACE')}</div>
        <button className={'nav-item' + (activeNav === 'dashboard' ? ' active' : '')} onClick={() => navigateToNav('dashboard')}>
          <LayoutDashboard size={18} />
          <span>{uiText(lang, 'Dashboard')}</span>
        </button>
        <button className={'nav-item' + (activeNav === 'expenses' ? ' active' : '')} onClick={() => navigateToNav('expenses')}>
          <WalletCards size={18} />
          <span>{t.activity}</span>
          <span className="nav-count">{expenses.length}</span>
        </button>
        <button className={'nav-item' + (activeNav === 'income' ? ' active' : '')} onClick={() => { navigateToNav('income'); if (family) void loadIncomes(family.id).catch(err => setErrorText(messageOf(err))); }}><ArrowDownLeft size={18} /><span>{lang === 'hi' ? 'आय' : uiText(lang, lang === 'ur' ? 'آمدنی' : 'Income')}</span><span className="nav-count">{incomes.length}</span></button>
        <button className={'nav-item' + (activeNav === 'deleted' ? ' active' : '')} onClick={() => { navigateToNav('deleted'); if (family) void api.get('/api/families/' + encodeURIComponent(family.id) + '/deleted-expenses').then(response => setDeletedExpenses((response.data as { expenses: Expense[] }).expenses)).catch(err => setErrorText(messageOf(err))); }}>
          <Trash2 size={18} />
          <span>{uiText(lang, 'Deleted Expenses')}</span>
          {deletedExpenses.length > 0 && <span className="nav-count">{deletedExpenses.length}</span>}
        </button>
        <div className="side-label nav-heading">{uiText(lang, 'REPORTS')}</div>
        <button className={'nav-item' + (activeNav === 'reports' ? ' active' : '')} onClick={() => navigateToNav('reports')}>
          <CreditCard size={18} /><span>{uiText(lang, 'Spending Reports')}</span>
        </button>
        <button className={'nav-item' + (activeNav === 'members' ? ' active' : '')} onClick={() => navigateToNav('members')}>
          <Users size={18} /><span>{uiText(lang, 'Member-wise Spending')}</span>
        </button>
        <div className="side-label nav-heading">{uiText(lang, 'MANAGE')}</div>
        <button className="nav-item" onClick={() => setModal('family')}><Users size={18} /><span>{uiText(lang, 'Groups & Members')}</span></button>
        <button className="nav-item" onClick={() => void createInvite()}><UserRound size={18} /><span>{t.invite}</span></button>
        <button className="nav-item" onClick={() => setProfileMenuOpen(true)}><ShieldCheck size={18} /><span>{uiText(lang, 'Settings & Notifications')}</span></button>
        <div className="sidebar-bottom">
          <div className="connection-card">
            <span className={'status-dot ' + connection}></span>
            <div>
              <b>
                {connection === 'live'
                  ? t.live
                  : connection === 'connecting'
                    ? t.connecting
                    : t.offline}
              </b>
              <small>
                {connection === 'live'
                  ? t.realtimeSync
                  : t.serverSaved}
              </small>
            </div>
          </div>
          <div className="profile-row">
            {user.picture ? (
              <img src={user.picture} alt="" className="avatar" />
            ) : (
              <div className="avatar avatar-placeholder" aria-hidden="true">
                <UserRound size={18} />
              </div>
            )}
            <div className="profile-text">
              <b>{user.name || t.familyMember}</b>
              <small>{user.email || t.signedIn}</small>
            </div>
            <button className="icon-button" title={t.signOut} onClick={signOut}>
              <LogOut size={17} />
            </button>
          </div>
        </div>
      </aside>
      <main className="main-area">
        <header className="topbar">
          <div className="crumb">
            <span>{t.workspace}</span>
            <span className="crumb-slash">/</span>
            <b>{family?.name || t.family}</b>
          </div>
          <div className="top-actions">
            <span className={'live-pill ' + connection}>
              <span className="status-dot"></span>
              {connection === 'live'
                ? t.live
                : connection === 'connecting'
                  ? t.connecting
                  : t.offline}
            </span>
            <LanguageSelect lang={lang} setLang={setLang} />
            <button
              className="avatar top-avatar topbar-profile"
              onClick={() => setProfileMenuOpen(true)}
              title={t.profileMenuLabel}
              aria-label={t.profileMenuLabel}
              aria-expanded={profileMenuOpen}
            >
              {user.picture ? <img src={user.picture} alt="" referrerPolicy="no-referrer" /> : <UserRound size={19} aria-hidden="true" />}
            </button>
            <button className="top-group-switch" type="button" onClick={() => setModal('family')} title={t.switchGroupLabel} aria-label={t.switchGroupLabel}>
              <Users size={16} /><span>{family?.name || t.noFamily}</span><ChevronDown size={15} />
            </button>
            <button className="primary top-invite" onClick={createInvite}>
              <Users size={16} />
              {t.invite}
            </button>
          </div>
        </header>
        <div className="content-wrap">
          <div className="page-heading">
            <div>
              <p className="eyebrow">{activeNav === 'dashboard' ? uiText(lang, 'DASHBOARD') : activeNav === 'expenses' ? uiText(lang, 'EXPENSES') : activeNav === 'income' ? uiText(lang, 'INCOME') : activeNav === 'deleted' ? uiText(lang, 'DELETED EXPENSES') : activeNav === 'reports' ? uiText(lang, 'REPORTS') : uiText(lang, 'MEMBER ANALYTICS')}</p>
              <h1>
                {activeNav === 'dashboard' ? <>{t.pageTitle} <span>{t.pageTitleAccent}</span></> : activeNav === 'expenses' ? uiText(lang, 'Expenses') : activeNav === 'income' ? uiText(lang, 'Income') : activeNav === 'deleted' ? uiText(lang, 'Deleted Expenses') : activeNav === 'reports' ? uiText(lang, 'Spending Reports') : uiText(lang, 'Member-wise Spending')}
              </h1>
              <p className="muted">{activeNav === 'dashboard' ? t.subtitle : activeNav === 'expenses' ? uiText(lang, 'View and manage active expense records.') : activeNav === 'income' ? uiText(lang, 'View income entries shared in this group.') : activeNav === 'deleted' ? uiText(lang, 'Restore deleted records or permanently remove them.') : activeNav === 'reports' ? uiText(lang, 'Review daily totals and spending by member.') : uiText(lang, 'Compare each group member’s spending.')}</p>
            </div>
            <div className="heading-actions">
              {activeNav === 'dashboard' && <>
                <button className="dashboard-tool-button" type="button" onClick={() => setModal('filters')} aria-label={uiText(lang, 'Filters')}><Filter size={18} /><span>{uiText(lang, lang === 'hi' ? 'फ़िल्टर' : 'Filters')}</span></button>
                <button className="dashboard-tool-button" type="button" onClick={() => setExportPanelOpen(open => !open)} aria-label={exportText.title} aria-expanded={exportPanelOpen}><Download size={18} /><span>{uiText(lang, lang === 'hi' ? 'एक्सपोर्ट' : 'Export')}</span></button>
                <button className="dashboard-tool-button" type="button" onClick={() => { setImportPreview([]); setImportFileName(''); setErrorText(''); setModal('import'); }} aria-label={uiText(lang, 'Import data')}><Upload size={18} /><span>{uiText(lang, lang === 'hi' ? 'इम्पोर्ट' : 'Import')}</span></button>
                <button className="primary all-expenses-main" type="button" onClick={() => openMetricDetails('allExpenses')} disabled={!family}><WalletCards size={18} /><span>{lang === 'hi' ? 'सभी खर्च' : uiText(lang, lang === 'ur' ? 'تمام اخراجات' : 'All expenses')}</span></button>
                <button className="primary add-main" onClick={() => { setErrorText(''); setModal('expense'); }} disabled={!family}><Plus size={19} /> {t.add}</button>
                <button className="primary add-income-main" type="button" onClick={() => { setIncomeAmount(''); setIncomeSource(''); setEditingIncome(null); setErrorText(''); setModal('income'); }} disabled={!family}><ArrowDownLeft size={19} /> {lang === 'hi' ? 'आय जोड़ें' : uiText(lang, lang === 'ur' ? 'آمدنی شامل کریں' : 'Add income')}</button>
              </>}
              {activeNav === 'expenses' && <>
                <button className="dashboard-tool-button" type="button" onClick={() => setModal('filters')}><Filter size={18} /><span>{uiText(lang, lang === 'hi' ? 'फ़िल्टर' : 'Filters')}</span></button>
                <button className="primary add-main" onClick={() => { setErrorText(''); setModal('expense'); }} disabled={!family}><Plus size={19} /> {t.add}</button>
              </>}
              {activeNav === 'income' && <button className="primary add-income-main" type="button" onClick={() => { setIncomeAmount(''); setIncomeSource(''); setEditingIncome(null); setErrorText(''); setModal('income'); }} disabled={!family}><ArrowDownLeft size={19} /> {uiText(lang, lang === 'hi' ? 'आय जोड़ें' : 'Add income')}</button>}
            </div>
          </div>

          {errorText && (
            <div className="alert">
              <span>{errorText}</span>
              <button
                className="text-button"
                onClick={() =>
                  family
                    ? void loadExpenses(family.id).catch(err =>
                        setErrorText(messageOf(err))
                      )
                    : void bootstrap()
                }
              >
                {t.retry}
              </button>
              <button className="close-alert" onClick={() => setErrorText('')}>
                <X size={16} />
              </button>
            </div>
          )}
          {!family ? (
            <section className="empty-family">
              <div className="empty-icon">
                <Users size={27} />
              </div>
              <h2>{t.noFamily}</h2>
              <p>{t.noFamilyText}</p>
              <button className="primary" onClick={() => setModal('family')}>
                <Plus size={17} />
                {t.create}
              </button>
            </section>
          ) : (
            <>
              {activeNav === 'dashboard' && (
              <section className="stats-grid income-overview-stats income-detail-stats" aria-label="Family and personal financial overview">
                <StatCard icon={<Users size={20} />} label="All family income" value={money(totalIncome)} note={incomes.length + ' ' + uiText(lang, 'shared income entries')} trend="total" onClick={() => openMetricDetails('familyIncome')} />
                <StatCard icon={<IndianRupee size={20} />} label="All family this month income" value={money(monthIncome)} note="Current calendar month" trend="month" onClick={() => openMetricDetails('familyMonthIncome')} />
                <StatCard icon={<ArrowDownLeft size={20} />} label="Your total income" value={money(myTotalIncome)} note={myIncomes.length + ' ' + uiText(lang, 'of your income entries')} trend="personal-income" onClick={() => openMetricDetails('myIncome')} />
                <StatCard icon={<ArrowDownLeft size={20} />} label="Your this month income" value={money(myMonthIncome)} note="Your income this month" trend="personal-month" onClick={() => openMetricDetails('myMonthIncome')} />
                <StatCard icon={<WalletCards size={20} />} label="Your total spent" value={money(myTotalSpent)} note={myExpenses.length + ' ' + uiText(lang, 'expenses added by you')} trend="entries" onClick={() => openMetricDetails('mySpent')} />
                <StatCard icon={<CreditCard size={20} />} label="Your this month spent" value={money(myMonthSpent)} note="Your expenses this month" trend="personal-spent" onClick={() => openMetricDetails('myMonthSpent')} />
                <StatCard icon={<Users size={20} />} label="All family total spent" value={money(total)} note={expenses.length + " shared expense entries"} trend="family-spent" onClick={() => openMetricDetails('familySpent')} />
                <StatCard icon={<CreditCard size={20} />} label="All family this month spent" value={money(monthTotal)} note="Group spending this month" trend="family-month-spent" onClick={() => openMetricDetails('familyMonthSpent')} />
                <StatCard icon={<WalletCards size={20} />} label="Your remaining balance" value={money(myRemainingBalance)} note="Your income minus your spending" trend="balance" onClick={() => openMetricDetails('myBalance')} />
              </section>
              )}
              {activeNav === 'dashboard' && exportPanelOpen && <><button className="export-backdrop" type="button" aria-label={uiText(lang, lang === 'hi' ? 'एक्सपोर्ट बंद करें' : 'Close export dialog')} onClick={() => setExportPanelOpen(false)} /><section className="export-panel" role="dialog" aria-modal="true" aria-label={exportText.title}>
                <div className="export-panel-heading"><div><p className="eyebrow">{exportText.title.toUpperCase()}</p><h2>{exportText.title}</h2><p>{exportText.subtitle}</p></div><button className="export-close-button" type="button" onClick={() => setExportPanelOpen(false)} aria-label={uiText(lang, lang === 'hi' ? 'एक्सपोर्ट बंद करें' : 'Close export dialog')} title={uiText(lang, lang === 'hi' ? 'बंद करें' : 'Close')}><X size={20} strokeWidth={2.5} /></button></div>
                <div className="export-filter-grid">
                  <label className="export-field"><span>{exportText.period}</span><select value={exportMode} onChange={e => { setExportMode(e.target.value as typeof exportMode); setExportSummary(null); }}><option value="all">{exportText.all}</option><option value="date">{exportText.date}</option><option value="weekday">{exportText.weekday}</option><option value="month">{exportText.month}</option><option value="range">{exportText.range}</option></select></label>
                  {exportMode === 'date' && <label className="export-field"><span>{t.dateLabel}</span><input type="date" value={exportDate} onChange={e => { setExportDate(e.target.value); setExportSummary(null); }} /></label>}
                  {exportMode === 'weekday' && <label className="export-field"><span>{exportText.weekday}</span><select value={exportWeekday} onChange={e => { setExportWeekday(e.target.value); setExportSummary(null); }}>{exportText.weekdays.map((name, index) => <option key={name} value={String(index)}>{name}</option>)}</select></label>}
                  {exportMode === 'month' && <label className="export-field"><span>{exportText.month}</span><input type="month" value={exportMonth} onChange={e => { setExportMonth(e.target.value); setExportSummary(null); }} /></label>}
                  {exportMode === 'range' && <><label className="export-field"><span>{exportText.from}</span><input type="date" value={exportFrom} onChange={e => { setExportFrom(e.target.value); setExportSummary(null); }} /></label><label className="export-field"><span>{exportText.to}</span><input type="date" value={exportTo} onChange={e => { setExportTo(e.target.value); setExportSummary(null); }} /></label></>}
                  <label className="export-field"><span>{exportText.group}</span><select value={exportGroupId} onChange={e => { setExportGroupId(e.target.value); setExportSummary(null); }}><option value="current">{exportText.current}{family ? ` · ${family.name}` : ''}</option><option value="all">{exportText.allGroups}</option>{families.filter(item => item.id !== family?.id).map(item => <option key={item.id} value={item.id}>{item.name}</option>)}</select></label>
                  <label className="export-field"><span>{exportText.member}</span><select value={exportMemberId} onChange={e => { setExportMemberId(e.target.value); setExportSummary(null); }}><option value="all">{exportText.allMembers}</option>{[...new Map([...familyMembers.map(member => [member.userId, member.name] as const), ...expenses.map(expense => [expense.creatorId, expense.creatorName] as const)]).entries()].map(([id, name]) => <option key={id} value={id}>{name}</option>)}</select></label>
                  <label className="export-field"><span>{exportText.min}</span><input type="number" min="0" step="0.01" value={exportMinAmount} onChange={e => { setExportMinAmount(e.target.value); setExportSummary(null); }} placeholder="0.00" /></label>
                  <label className="export-field"><span>{exportText.max}</span><input type="number" min="0" step="0.01" value={exportMaxAmount} onChange={e => { setExportMaxAmount(e.target.value); setExportSummary(null); }} placeholder="—" /></label>
                  <label className="export-field export-search-field"><span>{exportText.search}</span><input type="search" value={exportSearch} onChange={e => { setExportSearch(e.target.value); setExportSummary(null); }} placeholder={uiText(lang, lang === 'hi' ? 'जैसे राशन, नाम, समूह' : 'e.g. groceries, name, group')} /></label>
                </div>
                <div className="export-panel-footer"><div className="export-preview"><span>{exportText.last}</span><strong>{exportSummary ? `${exportSummary.count} ${exportText.count} · ${money(exportSummary.total)}` : exportText.subtitle}</strong></div><div className="export-actions"><button className="export-xlsx-button" type="button" disabled={exporting || !family} onClick={() => void exportSelectedData('xlsx')}><FileSpreadsheet size={17} /> {exporting ? exportText.loading : exportText.xlsx}</button><button className="export-pdf-button" type="button" disabled={exporting || !family} onClick={() => void exportSelectedData('pdf')}><FileText size={17} /> {exporting ? exportText.loading : exportText.pdf}</button></div></div>
              </section></>}
              {(activeNav === 'dashboard' || activeNav === 'reports') && <section className="daily-report-card">
                <div className="daily-report-heading">
                  <div><p className="eyebrow">{t.dayLabel.toUpperCase()}</p><h2>{t.dailyReport}</h2><p>{t.dailyTotal}</p></div>
                  <label className="filter-field daily-report-date"><span>{t.dateFilter}</span><input type="date" value={dailyReportDate} onChange={event => setDailyReportDate(event.target.value)} /></label>
                </div>
                <div className="daily-report-total"><span>{t.dailyTotal}</span><strong>{money(dailyTotal)}</strong><small>{dailyExpenses.length} {t.expenseCount}</small></div>
                <div className="daily-member-grid">
                  {dailyMemberSummaries.length ? dailyMemberSummaries.map(member => <div className="daily-member-card" key={member.id}>
                    <div className="member-avatar">{member.picture ? <img src={member.picture} alt="" referrerPolicy="no-referrer" /> : (member.name || 'U').slice(0, 1).toUpperCase()}</div>
                    <div className="daily-member-info"><b>{member.name}</b><small>{member.count} {t.expenseCount}</small></div><strong>{money(member.amount)}</strong>
                  </div>) : <p className="daily-empty">{t.noDailyExpenses}</p>}
                </div>
                {dailyExpenses.length > 0 && <div className="daily-report-table-wrap"><table className="expense-table daily-report-table"><thead><tr><th>{t.expenseDetails}</th><th>{t.creator}</th><th>{t.dateLabel} / {t.dayLabel}</th><th>{t.amount}</th></tr></thead><tbody>{dailyExpenses.slice().sort((a,b) => a.createdAt-b.createdAt).map(expense => <tr key={expense.id}><td>{expense.reason}</td><td>{expense.creatorName}</td><td>{new Intl.DateTimeFormat(lang === 'ur' ? 'ur-PK' : uiText(lang, lang === 'hi' ? 'hi-IN' : 'en-IN'), { weekday: 'short', day: 'numeric', month: 'short', year: 'numeric', hour: 'numeric', minute: '2-digit' }).format(expense.createdAt)}</td><td><strong>{money(expense.amount)}</strong></td></tr>)}</tbody></table></div>}
              </section>}
              {activeNav === 'members' && (
                <section className="member-report-page">
                  <div className="member-report-heading"><p className="eyebrow">{uiText(lang, 'MEMBER REPORT')}</p><h2>{uiText(lang, 'Member-wise Spending')}</h2><p>{uiText(lang, 'Only expense totals and entry counts for each group member.')}</p></div>
                  <div className="member-report-grid">
                    {incomeMemberSummaries.map(member => {
                      const memberExpenses = expenses.filter(expense => expense.creatorId === member.id);
                      const memberTotal = memberExpenses.reduce((sum, expense) => sum + expense.amount, 0);
                      return <article className="member-report-card" key={member.id}>
                        <div className="member-report-user"><span className="member-avatar">{member.picture ? <img src={member.picture} alt="" referrerPolicy="no-referrer" /> : (member.name || 'U').slice(0, 1).toUpperCase()}</span><div><b>{member.name || 'Member'}</b><small>{memberExpenses.length} {uiText(lang, 'expenses')}</small></div></div>
                        <strong>{money(memberTotal)}</strong><small className="member-report-caption">{uiText(lang, 'Total spending')}</small>
                      </article>;
                    })}
                  </div>
                  {incomeMemberSummaries.length === 0 && <p className="metric-empty">{uiText(lang, 'No member spending records yet.')}</p>}
                </section>
              )}
              {(activeNav === 'dashboard' || activeNav === 'expenses' || activeNav === 'income' || activeNav === 'deleted') && <div className={'dashboard-grid' + (activeNav === 'dashboard' ? '' : ' dashboard-grid-single')}>
                <section className="activity-card">
                  <div className="section-head">
                    <div>
                      <h2>{activeNav === 'income' ? (lang === 'hi' ? 'आय का रिकॉर्ड' : uiText(lang, lang === 'ur' ? 'آمدنی کا ریکارڈ' : 'Income records')) : activeNav === 'deleted' ? uiText(lang, 'Deleted Expenses') : t.recent}</h2>
                      <p>{activeNav === 'income' ? (uiText(lang, lang === 'hi' ? 'समूह के सभी सदस्यों की आय यहाँ साझा दिखेगी।' : 'Income entries shared by members of this group.')) : t.updates}</p>
                    </div>
                    <div className="filter-controls">
                      {(activeNav === 'dashboard' || activeNav === 'expenses') && (
<button className="dashboard-filter-summary" type="button" onClick={() => setModal('filters')}><Filter size={16} /><span>{uiText(lang, lang === 'hi' ? 'फ़िल्टर और खोज' : 'Filter & search')}</span><small>{[selectedDate ? 1 : 0, selectedMemberId !== 'all' ? 1 : 0, dashboardWeekday !== 'all' ? 1 : 0, dashboardSearch ? 1 : 0, dashboardMinAmount || dashboardMaxAmount ? 1 : 0].reduce((a, b) => a + b, 0) || (filter === 'month' ? 1 : 0)} {uiText(lang, lang === 'hi' ? 'लागू' : 'active')}</small></button>
                      )}
                    </div>
                  </div>

                  {activeNav === 'income' ? (
                    <div className="income-view">
                      <div className="deleted-view-heading"><div><h3>{uiText(lang, lang === 'hi' ? 'आय जोड़ें और देखें' : 'Track group income')}</h3><p>{uiText(lang, lang === 'hi' ? 'हर सदस्य की आय, खर्च और बचा हुआ बैलेंस देखें।' : 'View income, spending and balance for every group member.')}</p></div><button className="primary" type="button" onClick={() => { setIncomeAmount(''); setIncomeSource(''); setEditingIncome(null); setErrorText(''); setModal('income'); }}><Plus size={16} /> {uiText(lang, lang === 'hi' ? 'आय जोड़ें' : 'Add income')}</button></div>
                      <div className="income-member-grid">{incomeMemberSummaries.map(member => <article className="income-member-card" key={member.id}><div className="income-member-top"><span className="member-avatar">{member.picture ? <img src={member.picture} alt="" referrerPolicy="no-referrer" /> : (member.name || 'U').slice(0, 1).toUpperCase()}</span><div><b>{member.name || (uiText(lang, lang === 'hi' ? 'सदस्य' : 'Member'))}</b><small>{member.incomeCount} {uiText(lang, lang === 'hi' ? 'आय एंट्री' : 'income entries')}</small></div></div><div className="income-member-metrics"><span><small>{uiText(lang, lang === 'hi' ? 'आय' : 'Income')}</small><b>{money(member.income)}</b></span><span><small>{uiText(lang, lang === 'hi' ? 'खर्च' : 'Spending')}</small><b>{money(member.spending)}</b></span><span><small>{uiText(lang, lang === 'hi' ? 'बैलेंस' : 'Balance')}</small><b className={member.income - member.spending < 0 ? 'negative-balance' : ''}>{money(member.income - member.spending)}</b></span></div></article>)}</div>
                      {incomes.length === 0 ? <div className="empty-state"><div className="empty-icon"><ArrowDownLeft size={25} /></div><h3>{uiText(lang, lang === 'hi' ? 'अभी आय दर्ज नहीं है' : 'No income recorded yet')}</h3><p>{uiText(lang, lang === 'hi' ? 'अपनी पहली आय जोड़ें। समूह के सदस्यों को भी यह रिकॉर्ड दिखेगा।' : 'Add your first income entry. Other group members can see it too.')}</p><button className="primary" type="button" onClick={() => setModal('income')}><Plus size={16} /> {uiText(lang, lang === 'hi' ? 'आय जोड़ें' : 'Add income')}</button></div> : <div className="income-record-list">{incomes.map(item => <article className="income-record-row" key={item.id}><div className="income-record-icon"><ArrowDownLeft size={18} /></div><div className="income-record-main"><b>{item.source}</b><small>{item.creatorName} · {dateLabel(item.createdAt, lang)}</small></div><strong>{money(item.amount)}</strong><div className="income-record-actions">{(item.creatorId === user.userId || family.role === 'owner') && <><button className="edit-button" type="button" title={t.edit} aria-label={t.edit} onClick={() => openIncomeEdit(item)}><Pencil size={15} /></button><button className="delete-button" type="button" title={t.delete} aria-label={t.delete} onClick={() => { setPendingDeleteIncome(item); setErrorText(''); setModal('confirmDeleteIncome'); }}><Trash2 size={15} /></button></>}</div></article>)}</div>}
                    </div>
                  ) : activeNav === 'deleted' ? (
                    <div className="deleted-expenses-view">
                      <div className="deleted-view-heading"><div><h3>{uiText(lang, 'Deleted Expenses')}</h3><p>{uiText(lang, 'Restore an expense to return it to the main list, or permanently delete it.')}</p></div><button className="outline-button" type="button" onClick={() => navigateToNav('expenses')}>{uiText(lang, 'Back to expenses')}</button></div>
                      {deletedExpenses.length === 0 ? <div className="empty-state"><div className="empty-icon"><Trash2 size={25} /></div><h3>{uiText(lang, 'No deleted expenses')}</h3><p>{uiText(lang, 'Expenses you delete will appear here so you can restore them later.')}</p></div> : <div className="deleted-expense-list">{deletedExpenses.map(expense => <article className="deleted-expense-item" key={expense.id}><div className="deleted-expense-main"><b>{expense.reason}</b><span>{money(expense.amount)} · {dateLabel(expense.createdAt, lang)}</span><small>{uiText(lang, 'Added by')} {expense.creatorName}</small></div><div className="deleted-expense-actions"><button className="restore-expense-button" type="button" onClick={() => void restoreExpense(expense)}><RefreshCw size={15} /> {uiText(lang, 'Restore')}</button><button className="permanent-delete-button" type="button" onClick={() => { setPendingDeleteExpense(expense); setModal('confirmPermanentDelete'); }}><Trash2 size={15} /> {uiText(lang, 'Permanently delete')}</button></div></article>)}</div>}
                    </div>
                  ) : visibleExpenses.length === 0 ? (
                    <div className="empty-state">
                      <div className="empty-icon">
                        <IndianRupee size={25} />
                      </div>
                      <h3>{t.empty}</h3>
                      <p>{t.emptyText}</p>
                      <button
                        className="primary"
                        onClick={() => setModal('expense')}
                      >
                        <Plus size={17} />
                        {t.add}
                      </button>
                    </div>
                  ) : (
                    <div className="expense-table-wrap">
                      <table className="expense-table">
                        <thead><tr><th>{t.expenseDetails}</th><th>{t.dateLabel}</th><th>{t.amount}</th><th>{t.actionLabel}</th></tr></thead>
                        <tbody>
                          {visibleExpenses.map(expense => (
                            <tr key={expense.id}>
                              <td data-label={t.expenseDetails}>
                                <div className="table-expense-cell">
                                  <div className="expense-icon" aria-label={expense.creatorName}>
                                    {expense.creatorPicture ? <img src={expense.creatorPicture} alt={expense.creatorName} className="expense-avatar" referrerPolicy="no-referrer" /> : <span className="expense-avatar initials" aria-hidden="true">{(expense.creatorName || 'U').slice(0, 1).toUpperCase()}</span>}
                                  </div>
                                  <button type="button" className="expense-detail expense-detail-open" onClick={() => { setSelectedExpense(expense); setModal('expenseDetails'); }} aria-label={(uiText(lang, lang === 'hi' ? 'खर्च का विवरण खोलें: ' : 'Open expense details: ')) + expense.reason}><b>{expense.reason}</b><span>{t.creator} {expense.creatorName}</span><small>{uiText(lang, lang === 'hi' ? 'पूरा विवरण देखने के लिए टैप करें' : 'Tap to view full details')}</small></button>
                                </div>
                              </td>
                              <td data-label={t.dateLabel} className="table-date"><Clock3 size={13} /> {dateLabel(expense.createdAt, lang)}</td>
                              <td data-label={t.amount}><strong className="expense-amount">{money(expense.amount)}</strong></td>
                              <td data-label={t.actionLabel} className="table-action"><div className="expense-actions">{(expense.creatorId === user.userId || family.role === 'owner') && <><button className="edit-button" title={t.edit} aria-label={t.edit} onClick={() => openExpenseEdit(expense)}><Pencil size={15} /></button><button className="delete-button" title={t.delete} aria-label={t.delete} onClick={() => void deleteExpense(expense)}><Trash2 size={15} /></button></>}</div></td>
                            </tr>
                          ))}
                        </tbody>
                      </table>
                    </div>
                  )}
                  {activeNav === 'expenses' && nextCursor && (
                    <button
                      className="load-more"
                      onClick={() =>
                        family && void loadExpenses(family.id, nextCursor, true)
                      }
                    >
                      <RefreshCw size={15} /> {t.loadMore}
                    </button>
                  )}
                </section>
                {activeNav === 'dashboard' && <aside className="family-card">
                  <div className="family-card-art">
                    <div className="orbit orbit-one"></div>
                    <div className="orbit orbit-two"></div>
                    <div className="wallet-illustration">
                      <WalletCards size={38} />
                    </div>
                    <div className="float-chip">
                      <Check size={14} />
                      <span>{t.sharedSecure}</span>
                    </div>
                  </div>
                  <p className="eyebrow">{t.family.toUpperCase()}</p>
                  <h2>{family.name}</h2>
                  <p className="muted">{t.familyText}</p>
                  <div className="member-summary">
                    <div className="member-icon">
                      <Users size={18} />
                    </div>
                    <div>
                      <b>{t.familyWorkspace}</b>
                      <small>{t.sharedInvited}</small>
                    </div>
                  </div>
                  <button className="outline-button" onClick={createInvite}>
                    <Users size={16} />
                    {t.share}
                  </button>
                  <p className="privacy-note">
                    <ShieldCheck size={14} />
                    {t.familyHint}
                  </p>
                </aside>}
              </div>}
            </>
          )}
          <footer className="footer">
            <span>© 2026 ZoExpense</span>
            <span>
              <span className="footer-dot"></span> {uiText(lang, 'Your family, in sync')}
            </span>
          </footer>
        </div>
      </main>
      {expenseAlert && (
        <div className="expense-alert-toast" role="status" aria-live="assertive">
          <div className="expense-alert-icon"><BellRing size={22} /></div>
          <div className="expense-alert-copy"><b>{expenseAlert.title}</b><p>{expenseAlert.body}</p><small>ZoExpense · {lang === 'hi' ? 'नई एंट्री' : uiText(lang, lang === 'ur' ? 'نیا اندراج' : 'New expense')}</small></div>
          <button className="expense-alert-dismiss" aria-label={uiText(lang, 'Dismiss notification')} onClick={() => setExpenseAlert(null)}><X size={17} /></button>
        </div>
      )}
      {profileMenuOpen && (
        <div className="profile-menu-backdrop" onMouseDown={event => { if (event.target === event.currentTarget) setProfileMenuOpen(false); }}>
          <aside className="profile-menu-drawer" role="dialog" aria-modal="true" aria-label={t.profileMenuLabel}>
            <div className="profile-menu-heading">
              {user.picture ? <img src={user.picture} alt="" className="profile-menu-photo" referrerPolicy="no-referrer" /> : <div className="profile-menu-photo avatar-placeholder"><UserRound size={24} /></div>}
              <div className="profile-menu-user"><b>{user.name || t.familyMember}</b><small>{user.email || t.signedIn}</small></div>
              <button className="icon-button" onClick={() => setProfileMenuOpen(false)} aria-label={t.cancel}><X size={19} /></button>
            </div>
            <div className="profile-menu-actions">
              <p className="profile-menu-section-label">{uiText(lang, 'WORKSPACE')}</p>
              <button onClick={() => { setProfileMenuOpen(false); navigateToNav('dashboard'); }}><LayoutDashboard size={18} /><span>{uiText(lang, 'Dashboard')}</span></button>
              <button onClick={() => { setProfileMenuOpen(false); navigateToNav('expenses'); }}><WalletCards size={18} /><span>{t.activity}</span></button>
              <button onClick={() => { setProfileMenuOpen(false); navigateToNav('income'); if (family) void loadIncomes(family.id).catch(err => setErrorText(messageOf(err))); }}><ArrowDownLeft size={18} /><span>{uiText(lang, lang === 'hi' ? 'आय' : 'Income')}</span><small className="profile-menu-count">{incomes.length}</small></button>
              <button onClick={() => { setProfileMenuOpen(false); navigateToNav('deleted'); if (family) void api.get('/api/families/' + encodeURIComponent(family.id) + '/deleted-expenses').then(response => setDeletedExpenses((response.data as { expenses: Expense[] }).expenses)).catch(err => setErrorText(messageOf(err))); }}><Trash2 size={18} /><span>{uiText(lang, 'Deleted Expenses')}</span>{deletedExpenses.length > 0 && <small className="profile-menu-count">{deletedExpenses.length}</small>}</button>
              <p className="profile-menu-section-label">{uiText(lang, 'REPORTS')}</p>
              <button onClick={() => { setProfileMenuOpen(false); navigateToNav('reports'); }}><CreditCard size={18} /><span>{uiText(lang, 'Spending Reports')}</span></button>
              <button onClick={() => { setProfileMenuOpen(false); navigateToNav('members'); }}><Users size={18} /><span>{uiText(lang, 'Member-wise Spending')}</span></button>
              <p className="profile-menu-section-label">{uiText(lang, 'MANAGE')}</p>
              <button onClick={() => { setProfileMenuOpen(false); setModal('family'); }}><Users size={18} /><span>{uiText(lang, 'Groups & Members')}</span></button>
              <button onClick={() => { setProfileMenuOpen(false); setEditingFamilyId(null); setFamilyName(''); setErrorText(''); setModal('createFamily'); }}><Plus size={18} /><span>{t.createGroupLabel}</span></button>
              <button onClick={() => { setProfileMenuOpen(false); setModal('family'); }}><Users size={18} /><span>{t.switchGroupLabel}</span></button>
              <button onClick={() => { setProfileMenuOpen(false); void createInvite(); }}><UserRound size={18} /><span>{t.invite}</span></button>
              <button onClick={() => { setProfileMenuOpen(false); void togglePushNotifications(); }}><ShieldCheck size={18} /><span>{uiText(lang, 'Settings & Notifications')}</span><small className={'push-state ' + (pushEnabled ? 'on' : '')}>{pushEnabled ? uiText(lang, 'ON') : ''}</small></button>
              <button className="profile-menu-logout" onClick={() => { setProfileMenuOpen(false); void signOut(); }}><LogOut size={18} /><span>{t.signOut}</span></button>
            </div>
          </aside>
        </div>
      )}
      {modal && (
        <div
          className={'modal-backdrop' + (modal === 'metricDetails' ? ' metric-page-backdrop' : '') + (modal === 'filterResults' ? ' filter-results-backdrop' : '')}
          onMouseDown={e => {
            if (e.target === e.currentTarget && !busy) closeCurrentModal();
          }}
        >
          <section className={'modal-card' + (modal === 'filters' || modal === 'import' ? ' modal-card-wide' : '') + ((modal === 'income' || modal === 'editIncome') ? ' income-entry-modal' : '') + (modal === 'metricDetails' ? ' metric-page-modal' : '') + (modal === 'filterResults' ? ' filter-results-modal' : '')} role="dialog" aria-modal="true">
            <div className="modal-heading">
              <div className={'modal-icon' + ((modal === 'income' || modal === 'editIncome') ? ' income-modal-icon' : '')}>
                {modal === 'income' || modal === 'editIncome' ? <ArrowDownLeft size={22} /> : modal === 'expense' || modal === 'editExpense' ? <IndianRupee size={21} /> : modal === 'family' || modal === 'createFamily' || modal === 'editFamily' || modal === 'confirmDeleteGroup' ? <Users size={21} /> : modal === 'filters' ? <Filter size={21} /> : modal === 'import' ? <Upload size={21} /> : modal === 'confirmDeleteExpense' ? <Trash2 size={21} /> : <Bell size={21} />
              }</div>
              <button
                className="icon-button"
                onClick={() => { closeCurrentModal(); setEditingFamilyId(null); setEditingExpense(null); setFamilyName(''); }}
                aria-label={uiText(lang, 'Close')}
              >
                <X size={19} />
              </button>
            </div>
            {modal === 'metricDetails' && selectedMetric && (() => {
              const isIncomeMetric = selectedMetric === 'familyIncome' || selectedMetric === 'familyMonthIncome' || selectedMetric === 'myIncome' || selectedMetric === 'myMonthIncome';
              const isBalanceMetric = selectedMetric === 'myBalance';
              const isPersonalMetric = selectedMetric.startsWith('my');
              const isMonthMetric = selectedMetric === 'familyMonthIncome' || selectedMetric === 'myMonthIncome' || selectedMetric === 'myMonthSpent' || selectedMetric === 'familyMonthSpent';
              const inMonth = (stamp: number) => { const d = new Date(stamp), now = new Date(); return d.getMonth() === now.getMonth() && d.getFullYear() === now.getFullYear(); };
              const metricIncomeRows = incomes.filter(item => (!isPersonalMetric || item.creatorId === user?.userId) && (!isMonthMetric || inMonth(item.createdAt)));
              const metricExpenseRows = expenses.filter(item => (!isPersonalMetric || item.creatorId === user?.userId) && (!isMonthMetric || inMonth(item.createdAt)));
              const renderIncomeRows = (rows: Income[]) => rows.length ? rows.map(item => <article className="metric-detail-row" key={item.id}><div><b>{item.source}</b><small>{item.creatorName} · {dateLabel(item.createdAt, lang)}</small></div><strong>{money(item.amount)}</strong></article>) : <p className="metric-empty">{uiText(lang, 'No income entries for this period.')}</p>;
              const renderExpenseRows = (rows: Expense[]) => rows.length ? rows.map(item => <article className="metric-detail-row" key={item.id}><div><b>{item.reason}</b><small>{item.creatorName} · {dateLabel(item.createdAt, lang)}</small></div><strong>{money(item.amount)}</strong></article>) : <p className="metric-empty">{uiText(lang, 'No expense entries for this period.')}</p>;
              const closeMetricDetails = () => { setModal(null); setSelectedMetric(null); };
              return <div className="metric-details-content"><div className="metric-page-toolbar"><button className="metric-back-button" type="button" onClick={closeMetricDetails} aria-label={uiText(lang, lang === 'hi' ? 'वापस जाएँ' : 'Go back')}><ArrowLeft size={19} /><span>{lang === 'hi' ? 'वापस' : uiText(lang, lang === 'ur' ? 'واپس' : 'Back')}</span></button><span className="metric-selected-chip metric-selected-chip-active" aria-current="page"><span className="metric-selected-dot" /><span className="metric-selected-label">{metricLabels[selectedMetric]}</span><Check size={15} aria-hidden="true" /></span></div><div className="metric-page-title"><p className="eyebrow">{selectedMetric === 'allExpenses' ? uiText(lang, 'EXPENSE HISTORY') : uiText(lang, 'FINANCIAL BREAKDOWN')}</p><h2>{metricLabels[selectedMetric]}</h2></div><div className="metric-detail-total">{money(metricValues[selectedMetric])}</div><p className="muted metric-scope-label">{family?.name || 'Selected group'} · {isMonthMetric ? 'Current calendar month' : 'All recorded time'}</p>{isBalanceMetric ? <><h3>{uiText(lang, 'Your income')}</h3><div className="metric-detail-list">{renderIncomeRows(incomes.filter(item => item.creatorId === user?.userId))}</div><h3>{uiText(lang, 'Your spending')}</h3><div className="metric-detail-list">{renderExpenseRows(expenses.filter(item => item.creatorId === user?.userId))}</div></> : <div className="metric-detail-list">{isIncomeMetric ? renderIncomeRows(metricIncomeRows) : renderExpenseRows(metricExpenseRows)}</div>}</div>;
            })()}
            {modal === 'expenseDetails' && selectedExpense && (
              <div className="expense-details-modal-content">
                <p className="eyebrow">{uiText(lang, 'EXPENSE RECORD')}</p><h2>{selectedExpense.reason}</h2>
                <div className="expense-details-amount">{money(selectedExpense.amount)}</div>
                <div className="expense-details-grid"><div><small>{t.dateLabel}</small><b>{new Intl.DateTimeFormat(lang === 'ur' ? 'ur-PK' : uiText(lang, lang === 'hi' ? 'hi-IN' : 'en-IN'), { weekday: 'long', day: 'numeric', month: 'long', year: 'numeric' }).format(selectedExpense.createdAt)}</b></div><div><small>{uiText(lang, lang === 'hi' ? 'समय' : 'Time')}</small><b>{new Intl.DateTimeFormat(lang === 'ur' ? 'ur-PK' : uiText(lang, lang === 'hi' ? 'hi-IN' : 'en-IN'), { hour: 'numeric', minute: '2-digit' }).format(selectedExpense.createdAt)}</b></div><div><small>{t.creator}</small><b>{selectedExpense.creatorName}</b></div><div><small>{uiText(lang, lang === 'hi' ? 'समूह' : 'Group')}</small><b>{families.find(item => item.id === selectedExpense.familyId)?.name || family?.name || '—'}</b></div></div>
                <div className="modal-actions"><button className="outline-button" type="button" onClick={() => setModal(null)}>{t.cancel}</button>{(selectedExpense.creatorId === user.userId || family?.role === 'owner') && <><button className="outline-button" type="button" onClick={() => openExpenseEdit(selectedExpense)}><Pencil size={15} /> {t.edit}</button><button className="delete-confirm-button" type="button" onClick={() => void deleteExpense(selectedExpense)}><Trash2 size={15} /> {t.delete}</button></>}</div>
              </div>
            )}
            {modal === 'confirmPermanentDelete' && pendingDeleteExpense && (
              <div className="tool-modal-content confirm-action-content"><p className="eyebrow">{uiText(lang, 'PERMANENT ACTION')}</p><h2>{uiText(lang, 'Permanently delete this expense?')}</h2><p className="muted">{uiText(lang, 'This cannot be undone. The expense will be removed from Deleted Expenses forever.')}</p><div className="confirm-delete-summary"><b>{pendingDeleteExpense.reason}</b><span>{money(pendingDeleteExpense.amount)}</span></div>{errorText && <div className="alert">{uiText(lang, errorText)}</div>}<div className="modal-actions"><button className="outline-button" type="button" disabled={busy} onClick={() => setModal(null)}>{t.cancel}</button><button className="delete-confirm-button" type="button" disabled={busy} onClick={() => void permanentlyDeleteExpense()}><Trash2 size={16} /> {busy ? uiText(lang, 'Deleting…') : uiText(lang, 'Permanently delete')}</button></div></div>
            )}
            {modal === 'confirmDeleteIncome' && pendingDeleteIncome && (
              <div className="tool-modal-content confirm-action-content"><p className="eyebrow">{uiText(lang, lang === 'hi' ? 'पुष्टि आवश्यक' : 'CONFIRM ACTION')}</p><h2>{uiText(lang, lang === 'hi' ? 'आय हटाएँ?' : 'Delete this income?')}</h2><p className="muted">{uiText(lang, lang === 'hi' ? 'यह आय रिकॉर्ड समूह की सूची से हटा दिया जाएगा।' : 'This income record will be removed from the shared group list.')}</p><div className="confirm-delete-summary"><b>{pendingDeleteIncome.source}</b><strong>{money(pendingDeleteIncome.amount)}</strong></div>{errorText && <div className="alert">{uiText(lang, errorText)}</div>}<div className="modal-actions"><button type="button" className="outline-button" disabled={busy} onClick={() => { setPendingDeleteIncome(null); setModal(null); }}>{t.cancel}</button><button type="button" className="delete-confirm-button" disabled={busy} onClick={() => void confirmDeleteIncome()}><Trash2 size={16} /> {busy ? uiText(lang, 'Deleting…') : uiText(lang, 'Delete income')}</button></div></div>
            )}
            {(modal === 'income' || modal === 'editIncome') && (
              <form className="income-form" onSubmit={saveIncome}>
                <div className="income-form-hero"><span className="income-hero-orb income-hero-orb-one" /><span className="income-hero-orb income-hero-orb-two" /><div className="income-hero-icon"><ArrowDownLeft size={25} /></div><div className="income-hero-copy"><p className="eyebrow">{uiText(lang, lang === 'hi' ? 'आय का रिकॉर्ड' : 'INCOME TRACKER')}</p><h2>{modal === 'editIncome' ? (uiText(lang, lang === 'hi' ? 'आय संपादित करें' : 'Edit income')) : (uiText(lang, lang === 'hi' ? 'आय जोड़ें' : 'Add income'))}</h2><p>{uiText(lang, lang === 'hi' ? 'अपनी कमाई को आसानी से दर्ज करें।' : 'Give every earning a place in your family finances.')}</p></div><span className="income-hero-spark income-hero-spark-one">✦</span><span className="income-hero-spark income-hero-spark-two">✧</span></div>
                <p className="income-sharing-note"><Users size={15} /> {uiText(lang, lang === 'hi' ? 'यह एंट्री चुने हुए समूह के सदस्यों को दिखेगी।' : 'Shared with members of the selected group.')}</p>
                <label className="income-field-label">{uiText(lang, lang === 'hi' ? 'कितनी आय हुई?' : 'Income amount')}<div className="income-amount-input"><span>₹</span><input autoFocus type="number" min="0.01" max="100000000" step="0.01" required value={incomeAmount} onChange={event => setIncomeAmount(event.target.value)} placeholder="0" aria-label={uiText(lang, 'Income amount in rupees')} /><small>INR</small></div><small className="income-field-hint">{uiText(lang, lang === 'hi' ? 'केवल सकारात्मक रकम दर्ज करें।' : 'Enter the amount you received.')}</small></label>
                <label className="income-field-label">{uiText(lang, lang === 'hi' ? 'आय कहाँ से हुई?' : 'Income source')}<div className="income-source-input"><span><WalletCards size={18} /></span><input required maxLength={160} value={incomeSource} onChange={event => setIncomeSource(event.target.value)} placeholder={uiText(lang, lang === 'hi' ? 'जैसे वेतन, व्यापार, फ्रीलांस' : 'e.g. Salary, business, freelance')} /></div></label>
                {errorText && <div className="alert">{uiText(lang, errorText)}</div>}
                <div className="modal-actions income-modal-actions"><button type="button" className="outline-button" onClick={() => { setModal(null); setEditingIncome(null); setIncomeAmount(''); setIncomeSource(''); }}>{t.cancel}</button><button className="primary income-save-button" disabled={busy}><Plus size={18} />{busy ? t.saving : modal === 'editIncome' ? (uiText(lang, lang === 'hi' ? 'बदलाव सेव करें' : 'Save changes')) : (uiText(lang, lang === 'hi' ? 'आय सेव करें' : 'Save income'))}</button></div>
              </form>
            )}
            {(modal === 'expense' || modal === 'editExpense') && (
              <form onSubmit={saveExpense}>
                <p className="eyebrow">{t.newEntry.toUpperCase()}</p>
                <h2>{modal === 'editExpense' ? t.editExpense : t.add}</h2>
                <p className="muted">{t.expenseHint}</p>
                <label>
                  {t.amount}
                  <div className="amount-input">
                    <span>₹</span>
                    <input
                      autoFocus
                      type="number"
                      min="0.01"
                      step="0.01"
                      required
                      value={amount}
                      onChange={e => setAmount(e.target.value)}
                      placeholder="0.00"
                    />
                  </div>
                </label>
                <label>
                  {t.reason}
                  <input
                    required
                    maxLength={160}
                    value={reason}
                    onChange={e => setReason(e.target.value)}
                    placeholder={t.reasonPlaceholder}
                  />
                </label>
                {errorText && <div className="alert">{uiText(lang, errorText)}</div>}
                <div className="modal-actions">
                  <button
                    type="button"
                    className="outline-button"
                    onClick={() => { setModal(null); setEditingFamilyId(null); setEditingExpense(null); setFamilyName(''); }}
                  >
                    {t.cancel}
                  </button>
                  <button className="primary" disabled={busy}>
                    {modal === 'editExpense' ? <Pencil size={17} /> : <Plus size={17} />}
                    {busy ? t.saving : modal === 'editExpense' ? t.saveChanges : t.save}
                  </button>
                </div>
              </form>
            )}
            {modal === 'family' && (
              <form onSubmit={createFamily}>
                <p className="eyebrow">{t.familySpace.toUpperCase()}</p>
                <h2>{t.switchGroupLabel}</h2>
                <p className="muted">
                  {uiText(lang, lang === 'hi' ? 'जिस समूह में काम करना है, उसे चुनें। नया समूह बनाने के लिए प्रोफ़ाइल मेन्यू में अलग विकल्प इस्तेमाल करें।' : 'Choose an existing group to switch to. Use Create group in the profile menu to make a new one.')}
                </p>
                {families.length > 0 && (
                  <div className="family-list" aria-label={t.groupListLabel}>
                    {families.map(item => (
                      <div className="family-option-row" key={item.id}>
                        <button type="button" className={'family-option' + (family?.id === item.id ? ' selected' : '')} onClick={() => { setFamily(item); setModal(null); setEditingFamilyId(null); setFamilyName(''); setErrorText(''); }}>
                          <span className="family-dot"><Users size={16} /></span>
                          <span className="family-option-text"><b>{item.name}</b><small>{item.role === 'owner' ? t.createdByYou : t.joinedGroup}</small></span>
                          {family?.id === item.id && <Check size={17} />}
                        </button>
                        <div className="group-actions">
                          <button type="button" className={'default-group-button' + (defaultFamilyId === item.id ? ' active' : '')} title={defaultFamilyId === item.id ? t.defaultGroup : t.setDefaultGroup} aria-label={defaultFamilyId === item.id ? t.defaultGroup : t.setDefaultGroup} onClick={() => setDefaultGroup(item)}><Star size={14} fill={defaultFamilyId === item.id ? 'currentColor' : 'none'} /></button>
                          {item.role === 'owner' && <><button type="button" className="edit-button" title={t.editGroup} aria-label={t.editGroup} onClick={() => { setEditingFamilyId(item.id); setFamilyName(item.name); setErrorText(''); setModal('editFamily'); }}><Pencil size={14} /></button><button type="button" className="delete-button" title={t.deleteGroup} aria-label={t.deleteGroup} onClick={() => void deleteFamily(item)} disabled={busy}><Trash2 size={14} /></button></>}
                        </div>
                      </div>
                    ))}
                  </div>
                )}
                {family?.role === 'owner' && (
                  <section className="group-members-panel" aria-label={t.groupMembers}>
                    <div className="group-members-heading">
                      <div><h3>{t.groupMembers}</h3><p>{family.name}</p></div>
                      <strong>{familyMembers.length}</strong>
                    </div>
                    {familyMembers.map(member => (
                      <div className="group-member-row" key={member.userId}>
                        <span className="group-member-avatar"><UserRound size={16} /></span>
                        <span className="group-member-info"><b>{member.name || t.familyMember}</b><small>{member.role === 'owner' ? t.ownerRole : t.memberRole}</small></span>
                        {member.role !== 'owner' && <button type="button" className="remove-member-button" title={t.removeMember} aria-label={t.removeMember} disabled={busy} onClick={() => void removeFamilyMember(member)}><UserMinus size={15} /><span>{t.removeMember}</span></button>}
                      </div>
                    ))}
                    {familyMembers.length === 0 && <p className="muted">{t.noFamilyText}</p>}
                  </section>
                )}
                {errorText && <div className="alert">{uiText(lang, errorText)}</div>}
                <div className="modal-actions">
                  <button type="button" className="outline-button" onClick={() => { setModal(null); setEditingFamilyId(null); setFamilyName(''); }}>
                    {t.cancel}
                  </button>
                </div>
              </form>
            )}
            {modal === 'createFamily' && (
              <form onSubmit={createFamily}>
                <p className="eyebrow">{t.familySpace.toUpperCase()}</p>
                <h2>{t.createGroupLabel}</h2>
                <p className="muted">{uiText(lang, lang === 'hi' ? 'नया खर्च समूह बनाएँ। यहाँ मौजूदा समूह बदलने का विकल्प नहीं है।' : 'Create a new expense group. Switching between existing groups is handled separately.')}</p>
                <label>
                  {t.name}
                  <input autoFocus required maxLength={80} value={familyName} onChange={e => setFamilyName(e.target.value)} placeholder={uiText(lang, 'e.g. Home, Trip, Personal')} />
                </label>
                {errorText && <div className="alert">{uiText(lang, errorText)}</div>}
                <div className="modal-actions">
                  <button type="button" className="outline-button" onClick={() => { setModal(null); setFamilyName(''); setErrorText(''); }}>{t.cancel}</button>
                  <button className="primary" disabled={busy}><Plus size={17} />{busy ? t.creating : t.createGroupLabel}</button>
                </div>
              </form>
            )}
            {modal === 'editFamily' && (
              <form onSubmit={createFamily}>
                <p className="eyebrow">{t.familySpace.toUpperCase()}</p>
                <h2>{t.editGroup}</h2>
                <p className="muted">{t.name}: {families.find(item => item.id === editingFamilyId)?.name || family?.name || ''}</p>
                <label>
                  {t.name}
                  <input autoFocus required maxLength={80} value={familyName} onChange={e => setFamilyName(e.target.value)} placeholder="जैसे Our Family" />
                </label>
                {errorText && <div className="alert">{uiText(lang, errorText)}</div>}
                <div className="modal-actions">
                  <button type="button" className="outline-button" onClick={() => { setModal('family'); setEditingFamilyId(null); setFamilyName(''); setErrorText(''); }}>{t.cancel}</button>
                  <button className="primary" disabled={busy}><Pencil size={17} />{busy ? t.saving : t.saveChanges}</button>
                </div>
              </form>
            )}
            {modal === 'filters' && (
              <div className="tool-modal-content">
                <p className="eyebrow">{uiText(lang, lang === 'hi' ? 'खर्च व्यवस्थित करें' : 'EXPENSE CONTROLS')}</p><h2>{uiText(lang, lang === 'hi' ? 'फ़िल्टर और खोज' : 'Filter expenses')}</h2><p className="muted">{uiText(lang, lang === 'hi' ? 'सभी फ़िल्टर एक जगह। लागू करने पर केवल मिलते हुए खर्च दिखेंगे।' : 'Choose any combination. The expense list updates to match your filters.')}</p>
                <section className="member-filter-section">
                  <div className="member-filter-heading"><h3>{t.memberBreakdown}</h3><p>{uiText(lang, lang === 'hi' ? 'किसी सदस्य की प्रोफ़ाइल पर टैप करके उसके सभी खर्च देखें।' : 'Tap a member profile to see every expense they added.')}</p></div>
                  {allMemberSummaries.length ? <div className="member-filter-cards">{allMemberSummaries.map(member => <button key={member.id} type="button" className={'member-filter-card' + (selectedMemberId === member.id ? ' selected' : '')} onClick={() => { setSelectedMemberId(member.id); setFilter('all'); setSelectedDate(''); setDashboardWeekday('all'); setDashboardSearch(''); setDashboardMinAmount(''); setDashboardMaxAmount(''); setModal('filterResults'); }} aria-label={`${member.name}: ${money(member.amount)}, ${member.count} expenses`}><span className="member-filter-avatar">{member.picture ? <img src={member.picture} alt="" referrerPolicy="no-referrer" /> : (member.name || 'U').slice(0, 1).toUpperCase()}</span><span className="member-filter-person"><b>{member.name}</b><small>{member.count} {uiText(lang, lang === 'hi' ? 'खर्च' : 'expenses')}</small></span><strong>{money(member.amount)}</strong></button>)}</div> : <p className="muted">{uiText(lang, lang === 'hi' ? 'अभी किसी सदस्य ने खर्च नहीं जोड़ा है।' : 'No member expenses have been added yet.')}</p>}
                </section>
                <div className="tool-filter-grid">
                  <label className="export-field"><span>{exportText.group}</span><select value={family?.id || ''} onChange={event => { const selected = families.find(item => item.id === event.target.value); if (selected) { setFamily(selected); setSelectedMemberId('all'); } }}>{families.map(item => <option key={item.id} value={item.id}>{item.name}</option>)}</select></label>
                  <label className="export-field"><span>{exportText.member}</span><select value={selectedMemberId} onChange={event => setSelectedMemberId(event.target.value)}><option value="all">{exportText.allMembers}</option>{memberSummaries.map(member => <option key={member.id} value={member.id}>{member.name}</option>)}</select></label>
                  <label className="export-field"><span>{uiText(lang, lang === 'hi' ? 'समय अवधि' : 'Time period')}</span><select value={selectedDate ? 'date' : filter} onChange={event => { if (event.target.value === 'date') setFilter('all'); else { setFilter(event.target.value as 'all' | 'month'); setSelectedDate(''); } }}><option value="all">{exportText.all}</option><option value="month">{exportText.month}</option><option value="date">{exportText.date}</option></select></label>
                  <label className="export-field"><span>{exportText.date}</span><input type="date" value={selectedDate} onChange={event => { setSelectedDate(event.target.value); if (event.target.value) setFilter('all'); }} /></label>
                  <label className="export-field"><span>{exportText.weekday}</span><select value={dashboardWeekday} onChange={event => setDashboardWeekday(event.target.value)}><option value="all">{exportText.all}</option>{exportText.weekdays.map((day, index) => <option key={day} value={String(index)}>{day}</option>)}</select></label>
                  <label className="export-field"><span>{exportText.min}</span><input type="number" min="0" step="0.01" value={dashboardMinAmount} onChange={event => setDashboardMinAmount(event.target.value)} placeholder="0.00" /></label>
                  <label className="export-field"><span>{exportText.max}</span><input type="number" min="0" step="0.01" value={dashboardMaxAmount} onChange={event => setDashboardMaxAmount(event.target.value)} placeholder="—" /></label>
                  <label className="export-field"><span>{exportText.search}</span><input type="search" value={dashboardSearch} onChange={event => setDashboardSearch(event.target.value)} placeholder={uiText(lang, lang === 'hi' ? 'जैसे राशन, बिजली, सदस्य' : 'e.g. groceries, bills, member')} /></label>
                </div>
                <div className="modal-actions tool-modal-actions"><button type="button" className="outline-button" onClick={() => { setFilter('all'); setSelectedDate(''); setSelectedMemberId('all'); setDashboardWeekday('all'); setDashboardSearch(''); setDashboardMinAmount(''); setDashboardMaxAmount(''); }}>{uiText(lang, lang === 'hi' ? 'सभी साफ़ करें' : 'Clear all')}</button><button type="button" className="primary" onClick={() => setModal('filterResults')}><Check size={17} /> {uiText(lang, lang === 'hi' ? 'फ़िल्टर लागू करें' : 'Apply filters')}</button></div>
              </div>
            )}
            {modal === 'filterResults' && (
              <div className="filter-results-content">
                <div className="filter-results-toolbar">
                  <button className="filter-results-back" type="button" onClick={() => { clearAppliedFilters(); setModal(null); setSelectedMetric(null); setActiveNav('dashboard'); }} aria-label={uiText(lang, lang === 'hi' ? 'डैशबोर्ड पर वापस जाएँ' : 'Back to Dashboard')}>
                    <ArrowLeft size={19} />
                    <span>{lang === 'hi' ? 'डैशबोर्ड पर वापस' : uiText(lang, lang === 'ur' ? 'ڈیش بورڈ پر واپس' : 'Back to Dashboard')}</span>
                  </button>
                  <span className="filter-results-active-label"><Check size={14} /> {uiText(lang, lang === 'hi' ? 'फ़िल्टर लागू' : 'Filters applied')}</span>
                </div>
                <div className="filter-results-title">
                  <p className="eyebrow">{uiText(lang, lang === 'hi' ? 'फ़िल्टर परिणाम' : 'FILTER RESULTS')}</p>
                  <h2>{uiText(lang, lang === 'hi' ? 'फ़िल्टर किए गए खर्च' : 'Filtered expenses')}</h2>
                  <p>{uiText(lang, lang === 'hi' ? 'केवल चुने गए फ़िल्टर से मेल खाते खर्च दिख रहे हैं।' : 'Only expenses matching your selected filters are shown.')}</p>
                </div>
                <div className="filter-results-summary">
                  <div><small>{uiText(lang, lang === 'hi' ? 'मिलान वाले खर्च' : 'Matching expenses')}</small><strong>{visibleExpenses.length}</strong></div>
                  <div><small>{uiText(lang, lang === 'hi' ? 'कुल रकम' : 'Matching total')}</small><strong>{money(visibleExpenses.reduce((sum, expense) => sum + expense.amount, 0))}</strong></div>
                </div>
                <div className="filter-results-chips">
                  {selectedMemberId !== 'all' && <span>{memberSummaries.find(member => member.id === selectedMemberId)?.name || (uiText(lang, lang === 'hi' ? 'चुना हुआ सदस्य' : 'Selected member'))}</span>}
                  {selectedDate && <span>{uiText(lang, lang === 'hi' ? 'तारीख' : 'Date')}: {selectedDate}</span>}
                  {!selectedDate && filter === 'month' && <span>{uiText(lang, lang === 'hi' ? 'चालू महीना' : 'This month')}</span>}
                  {dashboardWeekday !== 'all' && <span>{exportText.weekdays[Number(dashboardWeekday)] || dashboardWeekday}</span>}
                  {dashboardMinAmount && <span>Min {money(Number(dashboardMinAmount))}</span>}
                  {dashboardMaxAmount && <span>Max {money(Number(dashboardMaxAmount))}</span>}
                  {dashboardSearch.trim() && <span>{uiText(lang, lang === 'hi' ? 'खोज' : 'Search')}: {dashboardSearch.trim()}</span>}
                  {selectedMemberId === 'all' && !selectedDate && filter !== 'month' && dashboardWeekday === 'all' && !dashboardMinAmount && !dashboardMaxAmount && !dashboardSearch.trim() && <span>{uiText(lang, lang === 'hi' ? 'सभी खर्च' : 'All expenses')}</span>}
                </div>
                <div className="filter-results-list">
                  {visibleExpenses.length === 0 ? (
                    <div className="empty-state filter-results-empty"><div className="empty-icon"><Filter size={24} /></div><h3>{uiText(lang, lang === 'hi' ? 'कोई खर्च नहीं मिला' : 'No matching expenses')}</h3><p>{uiText(lang, lang === 'hi' ? 'फ़िल्टर बदलें या सभी फ़िल्टर साफ़ करें।' : 'Edit your filters or clear them to see more expenses.')}</p><button className="outline-button" type="button" onClick={() => setModal('filters')}>{uiText(lang, lang === 'hi' ? 'फ़िल्टर बदलें' : 'Edit filters')}</button></div>
                  ) : visibleExpenses.map(expense => (
                    <button key={expense.id} className="filter-result-row" type="button" onClick={() => { setSelectedExpense(expense); setModal('expenseDetails'); }}>
                      <span className="filter-result-icon"><WalletCards size={18} /></span>
                      <span className="filter-result-info"><b>{expense.reason}</b><small>{expense.creatorName} · {dateLabel(expense.createdAt, lang)}</small></span>
                      <strong>{money(expense.amount)}</strong>
                      <ArrowUpRight size={16} aria-hidden="true" />
                    </button>
                  ))}
                </div>
                <div className="filter-results-footer">
                  <button className="outline-button" type="button" onClick={() => setModal('filters')}><Filter size={16} /> {uiText(lang, lang === 'hi' ? 'फ़िल्टर बदलें' : 'Edit filters')}</button>
                  <button className="primary" type="button" onClick={() => { clearAppliedFilters(); setModal(null); setSelectedMetric(null); setActiveNav('dashboard'); }}><ArrowLeft size={17} /> {uiText(lang, lang === 'hi' ? 'डैशबोर्ड' : 'Back to Dashboard')}</button>
                </div>
              </div>
            )}
            {modal === 'import' && (
              <div className="tool-modal-content">
                <p className="eyebrow">{uiText(lang, lang === 'hi' ? 'स्प्रेडशीट इम्पोर्ट' : 'SPREADSHEET IMPORT')}</p><h2>{uiText(lang, lang === 'hi' ? 'डेटा इम्पोर्ट करें' : 'Import expense data')}</h2>
                <p className="muted">{uiText(lang, lang === 'hi' ? 'Excel या CSV फ़ाइल चुनें। Amount और Expense/Reason कॉलम होने चाहिए। इम्पोर्ट से पहले डेटा जाँचें।' : 'Choose an Excel or CSV file with Amount and Expense/Reason columns. Review rows before importing.')}</p>
                <label className="import-file-picker"><Upload size={20} /><span>{importFileName || (uiText(lang, lang === 'hi' ? 'Excel/CSV फ़ाइल चुनें' : 'Choose an Excel/CSV file'))}</span><input type="file" accept=".xlsx,.xls,.csv" onChange={event => void handleImportFile(event.target.files?.[0])} /></label>
                {importPreview.length > 0 && <><div className="import-preview-summary"><span>{importPreview.filter(row => !row.error).length} {uiText(lang, lang === 'hi' ? 'सही पंक्तियाँ' : 'valid rows')}</span><span>{importPreview.filter(row => row.error).length} {uiText(lang, lang === 'hi' ? 'जाँचें' : 'rows need review')}</span></div><div className="import-preview-table-wrap"><table className="import-preview-table"><thead><tr><th>{uiText(lang, 'Row')}</th><th>{t.amount}</th><th>{uiText(lang, lang === 'hi' ? 'विवरण' : 'Expense')}</th><th>{uiText(lang, lang === 'hi' ? 'स्थिति' : 'Status')}</th></tr></thead><tbody>{importPreview.slice(0, 8).map(row => <tr key={row.rowNumber} className={row.error ? 'invalid-import-row' : ''}><td>{row.rowNumber}</td><td>{Number.isFinite(row.amount) ? money(row.amount) : '—'}</td><td>{row.reason || '—'}</td><td>{row.error || (uiText(lang, lang === 'hi' ? 'सही' : 'Ready'))}</td></tr>)}</tbody></table></div><p className="muted import-footnote">{uiText(lang, lang === 'hi' ? 'पहली 8 पंक्तियाँ दिखाई गई हैं। फ़ाइल की तारीख/समय लागू नहीं होते; इम्पोर्ट समय इस्तेमाल होगा।' : 'First 8 rows are previewed. Source file dates are not applied; imported entries use the import time.')}</p></>}
                {errorText && <div className="alert">{uiText(lang, errorText)}</div>}
                <div className="modal-actions tool-modal-actions"><button type="button" className="outline-button" onClick={() => { setImportPreview([]); setImportFileName(''); setModal(null); }}>{t.cancel}</button><button type="button" className="primary" disabled={importing || importPreview.filter(row => !row.error).length === 0} onClick={() => void importSelectedExpenses()}><Upload size={17} /> {importing ? (uiText(lang, lang === 'hi' ? 'इम्पोर्ट हो रहा है…' : 'Importing…')) : (uiText(lang, lang === 'hi' ? 'खर्च इम्पोर्ट करें' : 'Import expenses'))}</button></div>
              </div>
            )}
            {(modal === 'confirmDeleteExpense' || modal === 'confirmDeleteGroup') && (
              <div className="tool-modal-content confirm-action-content">
                <p className="eyebrow">{uiText(lang, lang === 'hi' ? 'पुष्टि आवश्यक' : 'CONFIRM ACTION')}</p>
                <h2>{modal === 'confirmDeleteExpense' ? (uiText(lang, lang === 'hi' ? 'खर्च हटाएँ?' : 'Delete this expense?')) : (uiText(lang, lang === 'hi' ? 'समूह हटाएँ?' : 'Delete this group?'))}</h2>
                <p className="muted">{modal === 'confirmDeleteExpense' ? (uiText(lang, lang === 'hi' ? 'यह खर्च और उसकी एंट्री हट जाएगी।' : 'This expense entry will be permanently removed.')) : (uiText(lang, lang === 'hi' ? 'इस समूह और उसके सभी खर्चों को हटाया जाएगा। यह वापस नहीं हो सकता।' : 'This group and all of its expenses will be permanently removed. This cannot be undone.'))}</p>
                {modal === 'confirmDeleteExpense' && pendingDeleteExpense && <div className="confirm-delete-summary"><b>{pendingDeleteExpense.reason}</b><strong>{money(pendingDeleteExpense.amount)}</strong></div>}
                {modal === 'confirmDeleteGroup' && pendingDeleteFamily && <div className="confirm-delete-summary"><b>{pendingDeleteFamily.name}</b><span>{uiText(lang, lang === 'hi' ? 'समूह' : 'Group')}</span></div>}
                {errorText && <div className="alert">{uiText(lang, errorText)}</div>}
                <div className="modal-actions"><button type="button" className="outline-button" disabled={busy} onClick={() => { setPendingDeleteExpense(null); setPendingDeleteFamily(null); setModal(null); }}>{t.cancel}</button><button type="button" className="delete-confirm-button" disabled={busy} onClick={() => void (modal === 'confirmDeleteExpense' ? confirmDeleteExpense() : confirmDeleteFamily())}><Trash2 size={16} /> {busy ? (uiText(lang, lang === 'hi' ? 'हटाया जा रहा है…' : 'Deleting…')) : (uiText(lang, lang === 'hi' ? 'हाँ, हटाएँ' : 'Yes, delete'))}</button></div>
              </div>
            )}
            {modal === 'confirmRemoveMember' && (
              <div className="tool-modal-content confirm-action-content">
                <p className="eyebrow">{uiText(lang, lang === 'hi' ? 'पुष्टि आवश्यक' : 'CONFIRM ACTION')}</p>
                <h2>{uiText(lang, lang === 'hi' ? 'सदस्य हटाएँ?' : 'Remove family member?')}</h2>
                <p className="muted">{uiText(lang, lang === 'hi' ? 'यह सदस्य इस समूह के साझा खर्चों को आगे नहीं देख पाएगा।' : 'This member will lose access to this group and its shared expenses.')}</p>
                {pendingRemoveMember && <div className="confirm-delete-summary"><b>{pendingRemoveMember.name || t.familyMember}</b><span>{pendingRemoveMember.role === 'owner' ? t.ownerRole : t.memberRole}</span></div>}
                {errorText && <div className="alert">{uiText(lang, errorText)}</div>}
                <div className="modal-actions"><button type="button" className="outline-button" disabled={busy} onClick={() => { setPendingRemoveMember(null); setModal('family'); setErrorText(''); }}>{t.cancel}</button><button type="button" className="delete-confirm-button" disabled={busy || !pendingRemoveMember} onClick={() => void confirmRemoveFamilyMember()}><UserMinus size={16} /> {busy ? (uiText(lang, lang === 'hi' ? 'हटाया जा रहा है…' : 'Removing…')) : (uiText(lang, lang === 'hi' ? 'हाँ, हटाएँ' : 'Yes, remove'))}</button></div>
              </div>
            )}
            {modal === 'invite' && (
              <div>
                <p className="eyebrow">{uiText(lang, 'FAMILY INVITATION')}</p>
                <h2>{t.invite}</h2>
                <p className="muted">{t.familyHint}</p>
                <div className="invite-link">{inviteUrl}</div>
                <button
                  className="primary wide"
                  onClick={() => {
                    void navigator.clipboard.writeText(inviteUrl);
                    setErrorText(t.inviteCopied);
                  }}
                >
                  <Check size={17} />
                  {t.inviteCopied}
                </button>
                <div className="modal-actions">
                  <button
                    className="outline-button"
                    onClick={() => { setModal(null); setEditingFamilyId(null); setEditingExpense(null); setFamilyName(''); }}
                  >
                    {t.cancel}
                  </button>
                </div>
              </div>
            )}
          </section>
        </div>
      )}
      {pendingCode && inviteFamily && (
        <div className="modal-backdrop">
          <section className="modal-card" role="dialog" aria-modal="true">
            <div className="modal-heading">
              <div className="modal-icon">
                <Users size={21} />
              </div>
              <button
                className="icon-button"
                onClick={() => {
                  invitesClient.clearPendingCode();
                  setPendingCode(null);
                  setInviteFamily(null);
                }}
                aria-label={uiText(lang, 'Close')}
              >
                <X size={19} />
              </button>
            </div>
            <p className="eyebrow">{uiText(lang, 'FAMILY INVITATION')}</p>
            <h2>{inviteFamily.name}</h2>
            <p className="muted">
              आपको इस परिवार के साझा खर्च देखने और जोड़ने के लिए आमंत्रित किया
              गया है।
            </p>
            {errorText && <div className="alert">{uiText(lang, errorText)}</div>}
            <button
              className="primary wide"
              disabled={busy}
              onClick={() => void joinFamily()}
            >
              {busy ? t.joining : t.join}
            </button>
          </section>
        </div>
      )}
    </div>
  );
}

function StatCard({
  icon, label, value, note, trend, onClick,
}: {
  icon: React.ReactNode;
  label: string;
  value: string;
  note: string;
  trend: string;
  onClick?: () => void;
}) {
  const content = (
    <>
      <div className="stat-top">
        <div className={'stat-icon ' + trend}>{icon}</div>
        <span className="stat-open-indicator" aria-hidden="true">↗</span>
      </div>
      <p>{label}</p>
      <strong>{value}</strong>
      <small>{note}</small>
    </>
  );
  return onClick ? (
    <button className="stat-card stat-card-clickable" type="button" onClick={onClick} aria-label={'View details: ' + label}>
      {content}
    </button>
  ) : <article className="stat-card">{content}</article>;
}
function LanguageSelect({
  lang,
  setLang,
}: {
  lang: Lang;
  setLang: (v: Lang) => void;
}) {
  return (
    <label className="language-select" aria-label={uiText(lang, 'Language')}>
      <Languages size={15} />
      <select value={lang} onChange={e => setLang(e.target.value as Lang)}>
        <option value="hi">हिन्दी</option>
        <option value="en">English</option>
        <option value="ur">اردو</option>
      </select>
      <ChevronDown size={13} />
    </label>
  );
}
