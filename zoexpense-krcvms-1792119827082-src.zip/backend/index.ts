import {
  db,
  error,
  invites,
  isInviteError,
  json,
  notifications,
  requireAuth,
  router,
} from '@appdeploy/sdk';
import {
  notifySubscribers,
  addSubscription,
  removeSubscriptions,
} from './realtime-subscribers';

type Family = {
  name: string;
  ownerId: string;
  ownerName: string;
  createdAt: number;
};
type Membership = {
  familyId: string;
  familyName: string;
  role: 'owner' | 'member';
  joinedAt: number;
};
type Expense = {
  familyId: string;
  amount: number;
  reason: string;
  currency: 'INR';
  creatorId: string;
  creatorName: string;
  creatorPicture?: string;
  createdAt: number;
  deletedAt?: number;
};
type Income = { familyId: string; amount: number; source: string; currency: 'INR'; creatorId: string; creatorName: string; creatorPicture?: string; createdAt: number };
const membershipsTable = (userId: string) => `memberships:${userId}`;
const familyMembersTable = (familyId: string) => `family_members:${familyId}`;
const expensesTable = (familyId: string) => `expenses:${familyId}`;
const incomesTable = (familyId: string) => `incomes:${familyId}`;

async function ensureFamilyMember(familyId: string, userId: string, name: string) {
  const { items } = await db.list<{ userId: string; name: string }>(familyMembersTable(familyId), { limit: 100 });
  if (items.some(item => item.userId === userId)) return;
  await db.add(familyMembersTable(familyId), [{ userId, name, joinedAt: Date.now() }]);
}

async function membershipFor(userId: string, familyId: string) {
  const { items } = await db.list<Membership>(membershipsTable(userId), {
    limit: 100,
  });
  return items.find(item => item.familyId === familyId) || null;
}
async function requireMember(userId: string, familyId: string) {
  if (!familyId || familyId.length > 200)
    throw new Error('A valid family ID is required.');
  const membership = await membershipFor(userId, familyId);
  if (!membership) throw new Error('You are not a member of this family.');
  return membership;
}
function safeMessage(err: unknown) {
  return err instanceof Error
    ? err.message
    : 'Something went wrong. Please try again.';
}
function failed(err: unknown) {
  const message = safeMessage(err);
  const status = /not a member|not authorized|only the group owner|only the owner|you can edit only|you can delete only/i.test(message)
    ? 403
    : /required|valid|greater than zero/i.test(message)
      ? 400
      : 500;
  return error(message, status);
}

export const handler = router({
  'GET /api/_healthcheck': [async () => json({ message: 'Success' })],

  'GET /api/preferences': [
    requireAuth(),
    async ctx => {
      try {
        const userId = ctx.user!.userId;
        const { items: memberships } = await db.list<Membership>(membershipsTable(userId), { limit: 100 });
        const { items: records } = await db.list<{ defaultFamilyId?: string }>(`preferences:${userId}`, { limit: 1 });
        const savedId = records[0]?.defaultFamilyId || '';
        const defaultFamilyId = memberships.some(item => item.familyId === savedId) ? savedId : '';
        return json({ defaultFamilyId });
      } catch (err) { return failed(err); }
    },
  ],

  'PATCH /api/preferences': [
    requireAuth(),
    async ctx => {
      try {
        const userId = ctx.user!.userId;
        const body = (ctx.body || {}) as { defaultFamilyId?: string };
        const defaultFamilyId = typeof body.defaultFamilyId === 'string' ? body.defaultFamilyId.trim() : '';
        if (!defaultFamilyId || defaultFamilyId.length > 200) return error('Choose a valid default group.', 400);
        await requireMember(userId, defaultFamilyId);
        const table = `preferences:${userId}`;
        const { items } = await db.list<{ defaultFamilyId?: string }>(table, { limit: 1 });
        if (items[0]) {
          const [updated] = await db.update(table, [{ id: items[0].id, record: { ...items[0], defaultFamilyId } }]);
          if (!updated) return error('The default group could not be saved. Please retry.', 500);
        } else {
          const [created] = await db.add(table, [{ defaultFamilyId, updatedAt: Date.now() }]);
          if (!created) return error('The default group could not be saved. Please retry.', 500);
        }
        return json({ defaultFamilyId });
      } catch (err) { return failed(err); }
    },
  ],

  'GET /api/families': [
    requireAuth(),
    async ctx => {
      try {
        const { items } = await db.list<Membership>(
          membershipsTable(ctx.user!.userId),
          { limit: 100 }
        );
        await Promise.all(items.map(item => ensureFamilyMember(
          item.familyId,
          ctx.user!.userId,
          ctx.user!.name || ctx.user!.email || 'Family member'
        )));
        return json({
          families: items.map(item => ({
            id: item.familyId,
            name: item.familyName,
            role: item.role,
          })),
        });
      } catch (err) {
        return failed(err);
      }
    },
  ],

  'POST /api/families': [
    requireAuth(),
    async ctx => {
      try {
        const body = (ctx.body || {}) as { name?: string };
        const name = body.name?.trim();
        if (!name || name.length > 80)
          return error('Enter a family name (up to 80 characters).', 400);
        const [familyId] = await db.add('families', [
          {
            name,
            ownerId: ctx.user!.userId,
            ownerName: ctx.user!.name || ctx.user!.email || 'Family owner',
            createdAt: Date.now(),
          },
        ]);
        if (!familyId)
          return error('Family could not be saved. Please try again.', 500);
        const [membershipId] = await db.add(
          membershipsTable(ctx.user!.userId),
          [{ familyId, familyName: name, role: 'owner', joinedAt: Date.now() }]
        );
        if (!membershipId)
          return error(
            'Family was created but membership could not be saved. Refresh and retry.',
            500
          );
        await ensureFamilyMember(familyId, ctx.user!.userId, ctx.user!.name || ctx.user!.email || 'Family owner');
        return json({ family: { id: familyId, name, role: 'owner' } }, 201);
      } catch (err) {
        return failed(err);
      }
    },
  ],

  'PATCH /api/families/:id': [
    requireAuth(),
    async ctx => {
      try {
        const familyId = ctx.params.id;
        const body = (ctx.body || {}) as { name?: string };
        const name = body.name?.trim();
        if (!name || name.length > 80) return error('Enter a group name (up to 80 characters).', 400);
        const [record] = await db.get<Family>('families', [familyId]);
        if (!record) return error('This group could not be found.', 404);
        if (record.ownerId !== ctx.user!.userId) return error('Only the group owner can rename this group.', 403);
        const [updated] = await db.update('families', [{ id: familyId, record: { ...record, name } }]);
        if (!updated) return error('The group name was not updated. Please retry.', 500);
        const { items: members } = await db.list<{ userId: string; name: string }>(familyMembersTable(familyId), { limit: 100 });
        await Promise.all(members.map(async member => {
          const { items } = await db.list<Membership>(membershipsTable(member.userId), { limit: 100 });
          const membership = items.find(item => item.familyId === familyId);
          if (membership) await db.update(membershipsTable(member.userId), [{ id: membership.id, record: { ...membership, familyName: name } }]);
        }));
        return json({ family: { id: familyId, name, role: 'owner' } });
      } catch (err) { return failed(err); }
    },
  ],

  'DELETE /api/families/:id': [
    requireAuth(),
    async ctx => {
      try {
        const familyId = ctx.params.id;
        const [record] = await db.get<Family>('families', [familyId]);
        if (!record) return error('This group could not be found.', 404);
        if (record.ownerId !== ctx.user!.userId) return error('Only the group owner can delete this group.', 403);
        const allExpenseIds: string[] = [];
        let expenseCursor: string | undefined;
        do {
          const page = await db.list<Expense>(expensesTable(familyId), { limit: 100, ...(expenseCursor ? { nextToken: expenseCursor } : {}) });
          allExpenseIds.push(...page.items.map(item => item.id));
          expenseCursor = page.nextToken;
        } while (expenseCursor);
        for (let i = 0; i < allExpenseIds.length; i += 100) {
          const deleted = await db.delete(expensesTable(familyId), allExpenseIds.slice(i, i + 100));
          if (deleted.some(ok => !ok)) return error('Some expenses could not be deleted; please retry.', 500);
        }
        const { items: members } = await db.list<{ userId: string; name: string }>(familyMembersTable(familyId), { limit: 100 });
        for (const member of members) {
          const { items: memberships } = await db.list<Membership>(membershipsTable(member.userId), { limit: 100 });
          const matching = memberships.filter(item => item.familyId === familyId);
          if (matching.length) {
            const deleted = await db.delete(membershipsTable(member.userId), matching.map(item => item.id));
            if (deleted.some(ok => !ok)) return error('Group membership cleanup failed; please retry.', 500);
          }
        }
        const memberRows = await db.delete(familyMembersTable(familyId), members.map(member => member.id));
        if (memberRows.some(ok => !ok)) return error('Group member cleanup failed; please retry.', 500);
        const [deletedFamily] = await db.delete('families', [familyId]);
        if (!deletedFamily) return error('The group was not deleted. Please retry.', 500);
        return json({ ok: true, familyId });
      } catch (err) { return failed(err); }
    },
  ],

  'GET /api/families/:id/members': [
    requireAuth(),
    async ctx => {
      try {
        const familyId = ctx.params.id;
        await requireMember(ctx.user!.userId, familyId);
        const [familyRecord] = await db.get<Family>('families', [familyId]);
        if (!familyRecord) return error('This group could not be found.', 404);
        const { items } = await db.list<{ userId: string; name: string; joinedAt?: number }>(familyMembersTable(familyId), { limit: 100 });
        const members = items.map(item => ({ userId: item.userId, name: item.name || 'Family member', joinedAt: item.joinedAt, role: item.userId === familyRecord.ownerId ? 'owner' : 'member' }));
        return json({ members, count: members.length });
      } catch (err) { return failed(err); }
    },
  ],

  'DELETE /api/families/:id/members/:userId': [
    requireAuth(),
    async ctx => {
      try {
        const familyId = ctx.params.id;
        const targetUserId = ctx.params.userId;
        const [familyRecord] = await db.get<Family>('families', [familyId]);
        if (!familyRecord) return error('This group could not be found.', 404);
        if (familyRecord.ownerId !== ctx.user!.userId) return error('Only the group owner can remove members.', 403);
        if (targetUserId === familyRecord.ownerId) return error('The group owner cannot remove themselves.', 400);
        const { items: members } = await db.list<{ userId: string; name: string }>(familyMembersTable(familyId), { limit: 100 });
        const target = members.find(member => member.userId === targetUserId);
        if (!target) return error('This member is not in the group.', 404);
        const { items: memberships } = await db.list<Membership>(membershipsTable(targetUserId), { limit: 100 });
        const membership = memberships.find(item => item.familyId === familyId);
        if (membership) {
          const [removedMembership] = await db.delete(membershipsTable(targetUserId), [membership.id]);
          if (!removedMembership) return error('The member could not be removed. Please retry.', 500);
        }
        const [removedMember] = await db.delete(familyMembersTable(familyId), [target.id]);
        if (!removedMember) return error('The member record could not be removed. Please retry.', 500);
        return json({ ok: true, familyId, userId: targetUserId });
      } catch (err) { return failed(err); }
    },
  ],

  'GET /api/families/:id/expenses': [
    requireAuth(),
    async ctx => {
      try {
        const familyId = ctx.params.id;
        await requireMember(ctx.user!.userId, familyId);
        const limit = Math.min(100, Math.max(1, Number(ctx.query.limit) || 50));
        const result = await db.list<Expense>(expensesTable(familyId), {
          limit,
          ...(ctx.query.cursor ? { nextToken: ctx.query.cursor } : {}),
        });
        const expenses = result.items
          .filter(item => !item.deletedAt)
          .map(item => ({ ...item, id: item.id }))
          .sort((a, b) => b.createdAt - a.createdAt);
        return json({ expenses, nextCursor: result.nextToken || null });
      } catch (err) {
        return failed(err);
      }
    },
  ],

  'GET /api/families/:id/deleted-expenses': [
    requireAuth(),
    async ctx => {
      try {
        const familyId = ctx.params.id;
        const membership = await requireMember(ctx.user!.userId, familyId);
        const result = await db.list<Expense>(expensesTable(familyId), { limit: 100 });
        const expenses = result.items.filter(item => item.deletedAt && (item.creatorId === ctx.user!.userId || membership.role === 'owner')).map(item => ({ ...item, id: item.id })).sort((a, b) => (b.deletedAt || 0) - (a.deletedAt || 0));
        return json({ expenses });
      } catch (err) { return failed(err); }
    },
  ],

  'POST /api/families/:id/expenses': [
    requireAuth(),
    async ctx => {
      try {
        const familyId = ctx.params.id;
        await requireMember(ctx.user!.userId, familyId);
        const body = (ctx.body || {}) as { amount?: number; reason?: string; creatorPicture?: string };
        const amount = Number(body.amount);
        const reason = body.reason?.trim();
        if (!Number.isFinite(amount) || amount <= 0 || amount > 100000000)
          return error('Amount must be greater than ₹0.', 400);
        if (!reason || reason.length > 160)
          return error('Enter a reason (up to 160 characters).', 400);
        const record: Expense = {
          familyId,
          amount,
          reason,
          currency: 'INR',
          creatorId: ctx.user!.userId,
          creatorName: ctx.user!.name || ctx.user!.email || 'Family member',
          creatorPicture: typeof body.creatorPicture === 'string' && /^https:\/\//i.test(body.creatorPicture) ? body.creatorPicture.slice(0, 2000) : undefined,
          createdAt: Date.now(),
        };
        const [id] = await db.add(expensesTable(familyId), [record]);
        if (!id)
          return error('The expense was not saved. Please try again.', 500);
        const saved = { ...record, id };
        await notifySubscribers('family_expenses', familyId, {
          action: 'created',
          expense: saved,
        });
        try {
          const { items: members } = await db.list<{ userId: string; name: string }>(familyMembersTable(familyId), { limit: 100 });
          const recipientIds = [...new Set(members.map(member => member.userId).filter(userId => userId !== ctx.user!.userId))];
          if (recipientIds.length > 0) {
            await notifications.send({
              userIds: recipientIds,
              notification: {
                title: 'New family expense',
                body: `${record.creatorName} added ${reason} · ₹${amount.toLocaleString('en-IN')}`,
                url: '/',
              },
              data: { kind: 'family_expense', familyId, expenseId: id },
              ttlSeconds: 86400,
            });
          }
        } catch (notificationError) {
          console.error('Push notification delivery failed', notificationError);
        }
        return json({ expense: saved }, 201);
      } catch (err) {
        return failed(err);
      }
    },
  ],

  'PATCH /api/families/:familyId/expenses/:expenseId': [
    requireAuth(),
    async ctx => {
      try {
        const { familyId, expenseId } = ctx.params;
        const membership = await requireMember(ctx.user!.userId, familyId);
        const [record] = await db.get<Expense>(expensesTable(familyId), [expenseId]);
        if (!record || record.familyId !== familyId) return error('This expense could not be found.', 404);
        if (record.creatorId !== ctx.user!.userId && membership.role !== 'owner') return error('You can edit only your own expenses.', 403);
        const body = (ctx.body || {}) as { amount?: number; reason?: string };
        const amount = Number(body.amount);
        const reason = body.reason?.trim();
        if (!Number.isFinite(amount) || amount <= 0 || amount > 100000000) return error('Amount must be greater than ₹0.', 400);
        if (!reason || reason.length > 160) return error('Enter a reason (up to 160 characters).', 400);
        const updatedRecord: Expense = { ...record, amount, reason };
        const [updated] = await db.update(expensesTable(familyId), [{ id: expenseId, record: updatedRecord }]);
        if (!updated) return error('The expense was not updated. Please retry.', 500);
        const saved = { ...updatedRecord, id: expenseId };
        await notifySubscribers('family_expenses', familyId, { action: 'updated', expense: saved });
        return json({ expense: saved });
      } catch (err) { return failed(err); }
    },
  ],

  'DELETE /api/families/:familyId/expenses/:expenseId': [
    requireAuth(),
    async ctx => {
      try {
        const { familyId, expenseId } = ctx.params;
        const membership = await requireMember(ctx.user!.userId, familyId);
        const [record] = await db.get<Expense>(expensesTable(familyId), [
          expenseId,
        ]);
        if (!record || record.familyId !== familyId)
          return error('This expense could not be found.', 404);
        if (
          record.creatorId !== ctx.user!.userId &&
          membership.role !== 'owner'
        )
          return error('You can delete only your own expenses.', 403);
        if (record.deletedAt) return json({ ok: true, expenseId, alreadyDeleted: true });
        const deletedRecord = { ...record, deletedAt: Date.now() };
        const [deleted] = await db.update(expensesTable(familyId), [{ id: expenseId, record: deletedRecord }]);
        if (!deleted)
          return error('The expense was not moved to Deleted Expenses. Please retry.', 500);
        await notifySubscribers('family_expenses', familyId, {
          action: 'deleted',
          expenseId,
        });
        return json({ ok: true, expenseId });
      } catch (err) {
        return failed(err);
      }
    },
  ],

  'POST /api/families/:familyId/expenses/:expenseId/restore': [
    requireAuth(),
    async ctx => {
      try {
        const { familyId, expenseId } = ctx.params;
        const membership = await requireMember(ctx.user!.userId, familyId);
        const [record] = await db.get<Expense>(expensesTable(familyId), [expenseId]);
        if (!record || record.familyId !== familyId || !record.deletedAt) return error('Deleted expense not found.', 404);
        if (record.creatorId !== ctx.user!.userId && membership.role !== 'owner') return error('You can restore only your own expenses.', 403);
        const { deletedAt: _deletedAt, ...restoredRecord } = record;
        const [restored] = await db.update(expensesTable(familyId), [{ id: expenseId, record: restoredRecord }]);
        if (!restored) return error('The expense could not be restored. Please retry.', 500);
        await notifySubscribers('family_expenses', familyId, { action: 'restored', expense: { ...restoredRecord, id: expenseId } });
        return json({ ok: true, expense: { ...restoredRecord, id: expenseId } });
      } catch (err) { return failed(err); }
    },
  ],

  'DELETE /api/families/:familyId/expenses/:expenseId/permanent': [
    requireAuth(),
    async ctx => {
      try {
        const { familyId, expenseId } = ctx.params;
        const membership = await requireMember(ctx.user!.userId, familyId);
        const [record] = await db.get<Expense>(expensesTable(familyId), [expenseId]);
        if (!record || record.familyId !== familyId || !record.deletedAt) return error('Deleted expense not found.', 404);
        if (record.creatorId !== ctx.user!.userId && membership.role !== 'owner') return error('You can permanently delete only your own expenses.', 403);
        const [deleted] = await db.delete(expensesTable(familyId), [expenseId]);
        if (!deleted) return error('The expense could not be permanently deleted. Please retry.', 500);
        return json({ ok: true, expenseId });
      } catch (err) { return failed(err); }
    },
  ],

  'GET /api/families/:id/incomes': [
    requireAuth(),
    async ctx => {
      try {
        const familyId = ctx.params.id;
        await requireMember(ctx.user!.userId, familyId);
        const result = await db.list<Income>(incomesTable(familyId), { limit: 100 });
        const incomes = result.items.map(item => ({ ...item, id: item.id })).sort((x, y) => y.createdAt - x.createdAt);
        return json({ incomes });
      } catch (err) { return failed(err); }
    },
  ],
  'POST /api/families/:id/incomes': [
    requireAuth(),
    async ctx => {
      try {
        const familyId = ctx.params.id;
        await requireMember(ctx.user!.userId, familyId);
        const body = (ctx.body || {}) as { amount?: number; source?: string; creatorPicture?: string };
        const amount = Number(body.amount); const source = body.source?.trim();
        if (!Number.isFinite(amount) || amount <= 0 || amount > 100000000) return error('Income must be greater than ₹0.', 400);
        if (!source || source.length > 160) return error('Enter an income source (up to 160 characters).', 400);
        const record: Income = { familyId, amount, source, currency: 'INR', creatorId: ctx.user!.userId, creatorName: ctx.user!.name || ctx.user!.email || 'Family member', creatorPicture: typeof body.creatorPicture === 'string' && /^https:\/\//i.test(body.creatorPicture) ? body.creatorPicture.slice(0, 2000) : undefined, createdAt: Date.now() };
        const [id] = await db.add(incomesTable(familyId), [record]);
        if (!id) return error('The income was not saved. Please try again.', 500);
        return json({ income: { ...record, id } }, 201);
      } catch (err) { return failed(err); }
    },
  ],
  'PATCH /api/families/:familyId/incomes/:incomeId': [
    requireAuth(),
    async ctx => {
      try {
        const { familyId, incomeId } = ctx.params;
        const membership = await requireMember(ctx.user!.userId, familyId);
        const [record] = await db.get<Income>(incomesTable(familyId), [incomeId]);
        if (!record || record.familyId !== familyId) return error('This income could not be found.', 404);
        if (record.creatorId !== ctx.user!.userId && membership.role !== 'owner') return error('You can edit only your own income.', 403);
        const body = (ctx.body || {}) as { amount?: number; source?: string };
        const amount = Number(body.amount); const source = body.source?.trim();
        if (!Number.isFinite(amount) || amount <= 0 || amount > 100000000) return error('Income must be greater than ₹0.', 400);
        if (!source || source.length > 160) return error('Enter an income source (up to 160 characters).', 400);
        const updatedRecord: Income = { ...record, amount, source };
        const [updated] = await db.update(incomesTable(familyId), [{ id: incomeId, record: updatedRecord }]);
        if (!updated) return error('The income was not updated. Please retry.', 500);
        return json({ income: { ...updatedRecord, id: incomeId } });
      } catch (err) { return failed(err); }
    },
  ],
  'DELETE /api/families/:familyId/incomes/:incomeId': [
    requireAuth(),
    async ctx => {
      try {
        const { familyId, incomeId } = ctx.params;
        const membership = await requireMember(ctx.user!.userId, familyId);
        const [record] = await db.get<Income>(incomesTable(familyId), [incomeId]);
        if (!record || record.familyId !== familyId) return error('This income could not be found.', 404);
        if (record.creatorId !== ctx.user!.userId && membership.role !== 'owner') return error('You can delete only your own income.', 403);
        const [deleted] = await db.delete(incomesTable(familyId), [incomeId]);
        if (!deleted) return error('The income was not deleted. Please retry.', 500);
        return json({ ok: true, incomeId });
      } catch (err) { return failed(err); }
    },
  ],

  'POST /api/families/:id/invites': [
    requireAuth(),
    async ctx => {
      try {
        const familyId = ctx.params.id;
        const membership = await requireMember(ctx.user!.userId, familyId);
        const created = await invites.create({
          resourceType: 'zoexpense_family',
          authMode: 'required',
          actor: ctx.user!,
          context: { familyId, familyName: membership.familyName },
        });
        return json({ code: created.code });
      } catch (err) {
        if (isInviteError(err)) return error(err.code, 400);
        return failed(err);
      }
    },
  ],

  'GET /api/invites/:code': [
    async ctx => {
      try {
        return json(await invites.resolve({ code: ctx.params.code }));
      } catch (err) {
        if (isInviteError(err)) return error(err.code, 400);
        return failed(err);
      }
    },
  ],

  'POST /api/invites/:code/join': [
    requireAuth(),
    async ctx => {
      try {
        const joined = await invites.join({
          code: ctx.params.code,
          actor: ctx.user!,
        });
        if (
          joined.resourceType !== 'zoexpense_family' ||
          !joined.context?.familyId ||
          typeof joined.context?.familyName !== 'string'
        )
          return error('This invitation is not for a ZoExpense family.', 400);
        const familyId = String(joined.context.familyId);
        const [currentFamily] = await db.get<Family>('families', [familyId]);
        if (!currentFamily) return error('This group no longer exists.', 404);
        const familyName = currentFamily.name;
        const existing = await membershipFor(ctx.user!.userId, familyId);
        if (existing)
          return json({
            family: {
              id: familyId,
              name: existing.familyName,
              role: existing.role,
            },
            alreadyMember: true,
          });
        const [membershipId] = await db.add(
          membershipsTable(ctx.user!.userId),
          [{ familyId, familyName, role: 'member', joinedAt: Date.now() }]
        );
        if (!membershipId)
          return error(
            'The invite was accepted, but membership could not be saved. Please retry.',
            500
          );
        await ensureFamilyMember(familyId, ctx.user!.userId, ctx.user!.name || ctx.user!.email || 'Family member');
        return json(
          { family: { id: familyId, name: familyName, role: 'member' } },
          201
        );
      } catch (err) {
        if (isInviteError(err)) return error(err.code, 400);
        return failed(err);
      }
    },
  ],

  'POST /api/families/:id/subscriptions': [
    requireAuth(),
    async ctx => {
      try {
        await requireMember(ctx.user!.userId, ctx.params.id);
        const body = (ctx.body || {}) as { connection_id?: string };
        if (!body.connection_id)
          return error('A connection ID is required.', 400);
        await addSubscription(
          'family_expenses',
          ctx.params.id,
          body.connection_id
        );
        return json({ ok: true });
      } catch (err) {
        return failed(err);
      }
    },
  ],

  'DELETE /api/families/:id/subscriptions': [
    requireAuth(),
    async ctx => {
      try {
        await requireMember(ctx.user!.userId, ctx.params.id);
        const body = (ctx.body || {}) as { connection_id?: string };
        if (body.connection_id)
          await removeSubscriptions(
            'family_expenses',
            ctx.params.id,
            body.connection_id
          );
        return json({ ok: true });
      } catch (err) {
        return failed(err);
      }
    },
  ],
});
